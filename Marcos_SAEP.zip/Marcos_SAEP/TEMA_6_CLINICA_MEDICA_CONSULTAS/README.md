# COMO EXECUTAR ESTE SISTEMA (PASSO A PASSO)

Você pode rodar os comandos tanto aqui na raiz quanto dentro da pasta `sistema/`.

---

## Passo 1: Criar o Banco de Dados no MySQL
Execute o comando abaixo no PowerShell (a senha do MySQL no SENAI é `Senai@118`):

```powershell
mysql -u root -pSenai@118 < clinica_db.sql
```
*(Nota: O arquivo `clinica_db.sql` está disponível aqui na raiz e também dentro da pasta `sistema/`).*

---

## Passo 2: Testar a Conexão com o Banco
Basta rodar no seu terminal:
```powershell
python testar_conexao.py
```
*(Se estiver dentro da pasta sistema, o comando é o mesmo).*

---

## Passo 3: Iniciar o Servidor Flask
Rode o comando:
```powershell
python app.py
```

Pronto! Acesse no navegador:
👉 **`http://localhost:5000`**

### Dados para Login:
- **Usuário:** `admin`
- **Senha:** `admin123`
*(Ou outros usuários de teste cadastrados no banco: `camila` / `carlos123`, `lucas` / `ana12345`).*
