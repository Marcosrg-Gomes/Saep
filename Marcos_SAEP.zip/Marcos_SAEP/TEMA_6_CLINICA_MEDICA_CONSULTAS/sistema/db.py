"""
Módulo de Acesso ao Banco de Dados MySQL
Fornece conexão limpa, execução segura e conversão de dados.
"""
import os
from datetime import date, datetime
import mysql.connector

# Parâmetros de conexão com suporte a variáveis de ambiente e fallback padrão do SENAI
CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "Senai@118"),
    "database": os.getenv("DB_NAME", "clinica_db"),
}


class ErroNegocio(Exception):
    """Exceção personalizada para validações de regra de negócio (devolvida em JSON)."""
    def __init__(self, mensagem, status=400):
        super().__init__(mensagem)
        self.mensagem = mensagem
        self.status = status


def query(sql, params=()):
    """
    Executa consulta SELECT e retorna uma lista de dicionários.
    Converte datas para strings ISO legíveis pelo JSON/Front-end.
    """
    with mysql.connector.connect(**CONFIG) as con, con.cursor(dictionary=True) as cur:
        cur.execute(sql, params)
        return [
            {
                k: v.isoformat() if isinstance(v, (date, datetime)) else v
                for k, v in row.items()
            }
            for row in cur.fetchall()
        ]


def execute(sql, params=()):
    """Executa comandos INSERT, UPDATE e DELETE com commit garantido."""
    with mysql.connector.connect(**CONFIG) as con, con.cursor() as cur:
        cur.execute(sql, params)
        con.commit()
        return cur.lastrowid


def buscar_um(sql, params, mensagem="Registro não encontrado."):
    """Retorna uma única linha ou lança erro 404 caso não exista."""
    linhas = query(sql, params)
    if not linhas:
        raise ErroNegocio(mensagem, 404)
    return linhas[0]


def bloquear_se_existir(sql, params, mensagem="Registro já existente."):
    """Garante unicidade: lança erro 409 caso a consulta retorne algum registro."""
    if query(sql, params):
        raise ErroNegocio(mensagem, 409)


def testar_conexao():
    """Valida a integridade da conexão com o banco de dados."""
    return query("SELECT DATABASE() AS banco, VERSION() AS versao")[0]
