-- ====================================================================
-- Script: clinica_db.sql | MySQL 8+
-- Tema: Clínica Médica & Consultas Especializadas
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS clinica_db;
CREATE DATABASE clinica_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clinica_db;

-- 1. Usuários do Sistema (Médicos e Recepcionistas)
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,            -- bcrypt
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Pacientes (Clientes com CPF protegido por LGPD)
CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,              -- CPF criptografado com bcrypt
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Prontuários / Convênios do Paciente (Recurso Secundário)
CREATE TABLE IF NOT EXISTS prontuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  numero_carteirinha VARCHAR(30) NOT NULL UNIQUE,  -- Identificador Único
  convenio VARCHAR(50) NOT NULL,                   -- Unimed, Bradesco, Particular
  tipo_sanguineo VARCHAR(10),                      -- O+, A+, B-, etc.
  alergias VARCHAR(255),
  CONSTRAINT fk_pront_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- 4. Especialidades / Procedimentos Médicos (Serviços)
CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

-- 5. Consultas e Exames Agendados (Agendamentos Ordenados por Data)
CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  prontuario_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_pront FOREIGN KEY (prontuario_id) REFERENCES prontuarios(id),
  CONSTRAINT fk_ag_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

-- ====================================================================
-- INSERÇÃO DE 3 REGISTROS OBRIGATÓRIOS POR TABELA
-- ====================================================================

-- Senhas: admin/admin123 | drlucas/carlos123 | julia/ana12345
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Dr. Marcelo Diretor', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Dr. Lucas Cardiologista', 'drlucas', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Júlia Recepção', 'julia', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

-- Pacientes (CPFs válidos com hash): 529.982.247-25 | 111.444.777-35 | 390.533.447-05
INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Beatriz Helena', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-5555', 'beatriz@email.com', 'Rua da Saúde, 100 - SP'),
('Carlos Eduardo', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-6666', 'carlos.edu@email.com', 'Av. Brasil, 250 - SP'),
('Débora Nascimento', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-7777', 'debora@email.com', 'Rua das Acácias, 89 - SP');

-- Prontuários vinculados
INSERT INTO prontuarios (cliente_id, numero_carteirinha, convenio, tipo_sanguineo, alergias) VALUES
(1, 'MED-2026-9081', 'Bradesco Saúde', 'O+', 'Alergia a dipirona e frutos do mar'),
(2, 'MED-2026-9082', 'Unimed Nacional', 'A+', 'Nenhuma alergia relatada'),
(3, 'MED-2026-9083', 'Particular', 'B-', 'Intolerância severa a lactose');

-- Procedimentos
INSERT INTO servicos (descricao, valor) VALUES
('Consulta Médica Geral', 200.00),
('Eletrocardiograma de Repouso', 130.00),
('Exame de Sangue e Hemograma Completo', 95.00);

-- Agendamentos com ordenação por data
INSERT INTO agendamentos (prontuario_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 09:30:00', 'AGENDADO', 'Primeira consulta de rotina'),
(2, 2, '2026-11-06 15:00:00', 'AGENDADO', 'Paciente com recomendação de repouso'),
(3, 3, '2026-11-07 07:30:00', 'AGENDADO', 'Jejum obrigatório de 10 horas');
