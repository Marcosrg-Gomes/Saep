-- ====================================================================
-- Script: restaurante_db.sql | MySQL 8+
-- Tema: Restaurante, Gastronomia & Reserva de Mesas / Eventos
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS restaurante_db;
CREATE DATABASE restaurante_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurante_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,              -- LGPD
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recurso Secundário: Mesas / Ambientes Reservados pelo Cliente
CREATE TABLE IF NOT EXISTS mesas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,                  -- Cliente titular da reserva principal
  codigo_mesa VARCHAR(20) NOT NULL UNIQUE,  -- Identificador Único da Mesa (Ex: MESA-VIP-01, MESA-VARANDA-04)
  capacidade_pessoas INT NOT NULL,
  localizacao VARCHAR(50) NOT NULL,         -- Salão Principal, Varanda Jardim, Área VIP
  restricao_alimentar VARCHAR(150),
  CONSTRAINT fk_mesa_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

-- Reservas de Horários
CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mesa_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_mesa FOREIGN KEY (mesa_id) REFERENCES mesas(id),
  CONSTRAINT fk_ag_rest_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Maître Principal', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Chef Executivo André', 'andre', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Carla Hostess', 'carla', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Eduardo Vasques', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-9191', 'eduardo@email.com', 'Rua Gastronômica, 100'),
('Camila Pitanga', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-9292', 'camila.p@email.com', 'Av. Gourmet, 850'),
('Rogério Ceni', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-9393', 'rogerio@email.com', 'Alameda das Trufas, 45');

INSERT INTO mesas (cliente_id, codigo_mesa, capacidade_pessoas, localizacao, restricao_alimentar) VALUES
(1, 'MESA-VARANDA-02', 4, 'Varanda Jardim', 'Mesa próxima aos aquecedores'),
(2, 'MESA-VIP-01', 2, 'Área VIP Executiva', 'Cliente vegetariana estrita'),
(3, 'MESA-SALAO-10', 8, 'Salão Principal', 'Aniversário de família');

INSERT INTO servicos (descricao, valor) VALUES
('Menu Degustação em 5 Passos (por pessoa)', 195.00),
('Taxa de Reserva de Espaço para Evento', 150.00),
('Harmonização Completa com Vinhos Selecionados', 120.00);

INSERT INTO agendamentos (mesa_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 20:30:00', 'AGENDADO', 'Comemoração de aniversário de casamento'),
(2, 2, '2026-11-07 13:00:00', 'AGENDADO', 'Jantar romântico com velas'),
(3, 3, '2026-11-08 21:00:00', 'AGENDADO', 'Servir bolo próprio no final');
