-- ====================================================================
-- Script: odonto_db.sql | MySQL 8+
-- Tema: Consultório Odontológico & Clínicas Dentárias
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS odonto_db;
CREATE DATABASE odonto_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE odonto_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,              -- LGPD
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recurso Secundário: Fichas Odontológicas / Prontuários Dentários do Paciente
CREATE TABLE IF NOT EXISTS fichas_odontologicas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  cro_responsavel VARCHAR(20) NOT NULL,        -- CRO do dentista que acompanha
  codigo_prontuario VARCHAR(30) NOT NULL UNIQUE, -- Identificador Único do Prontuário
  historico_sensibilidade VARCHAR(100),
  alergia_anestesia VARCHAR(100),
  CONSTRAINT fk_odonto_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ficha_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_ficha FOREIGN KEY (ficha_id) REFERENCES fichas_odontologicas(id),
  CONSTRAINT fk_ag_odonto_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

-- Registros obrigatórios (3 por tabela)
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Dra. Vanessa Ortodontista', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Dr. Fernando Cirurgião', 'fernando', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Tatiane Recepção', 'tatiane', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Julio Cesar Braga', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-3322', 'julio@email.com', 'Rua Sorriso, 10'),
('Renata Vasconcelos', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-4433', 'renata@email.com', 'Av. Odonto, 450'),
('Marcos Paulo Lima', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-5544', 'marcos@email.com', 'Alameda Dental, 30');

INSERT INTO fichas_odontologicas (cliente_id, cro_responsavel, codigo_prontuario, historico_sensibilidade, alergia_anestesia) VALUES
(1, 'SP-CRO-84920', 'PRONT-DENT-001', 'Sensibilidade severa ao frio', 'Nenhuma alergia'),
(2, 'SP-CRO-84920', 'PRONT-DENT-002', 'Sem sensibilidade relatada', 'Alergia a Lidocaína (usar Mepivacaína)'),
(3, 'SP-CRO-71234', 'PRONT-DENT-003', 'Sensibilidade pós-clareamento', 'Nenhuma alergia');

INSERT INTO servicos (descricao, valor) VALUES
('Profilaxia e Limpeza com Ultrassom', 180.00),
('Restauração Estética em Resina', 220.00),
('Manutenção de Aparelho Ortodôntico', 150.00);

INSERT INTO agendamentos (ficha_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 10:00:00', 'AGENDADO', 'Paciente com gengivite leve'),
(2, 2, '2026-11-07 14:30:00', 'AGENDADO', 'Atenção ao tipo de anestésico'),
(3, 3, '2026-11-08 11:00:00', 'AGENDADO', 'Troca de fios e borrachinhas');
