-- ====================================================================
-- Script: hotelaria_db.sql | MySQL 8+
-- Tema: Hotelaria, Pousada & Gestão de Reservas / Quartos
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS hotelaria_db;
CREATE DATABASE hotelaria_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotelaria_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,              -- LGPD
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Quartos / Acomodações do Hóspede (Recurso Secundário)
CREATE TABLE IF NOT EXISTS quartos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,                  -- Hóspede titular da reserva principal
  numero_quarto VARCHAR(10) NOT NULL UNIQUE, -- Identificador Único (Ex: 101, 204A)
  tipo VARCHAR(40) NOT NULL,                 -- Suíte Luxo, Standard, Família
  capacidade INT NOT NULL,
  andar INT NOT NULL,
  CONSTRAINT fk_quarto_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

-- Reservas / Diárias Agendadas
CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  quarto_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_quarto FOREIGN KEY (quarto_id) REFERENCES quartos(id),
  CONSTRAINT fk_ag_hotel_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Gerente Geral', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Lucas Concierge', 'lucas', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Amanda Recepção', 'amanda', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Mariana Fagundes', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-4321', 'mariana@email.com', 'Rua das Flores, 88'),
('Fernando Gomes', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-5432', 'fernando@email.com', 'Av. Oceânica, 400'),
('Camila Guimarães', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-6543', 'camila@email.com', 'Rua das Palmeiras, 15');

INSERT INTO quartos (cliente_id, numero_quarto, tipo, capacidade, andar) VALUES
(1, '101', 'Suíte Master Casal', 2, 1),
(2, '205', 'Quarto Família Especial', 4, 2),
(3, '310', 'Standard Solteiro', 1, 3);

INSERT INTO servicos (descricao, valor) VALUES
('Diária Completa com Café da Manhã', 280.00),
('Pacote Romântico com Espumante e Decoração', 150.00),
('Aluguel de Sala de Reunião por Turno', 200.00);

INSERT INTO agendamentos (quarto_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 14:00:00', 'AGENDADO', 'Check-in antecipado solicitado'),
(2, 2, '2026-11-07 19:00:00', 'AGENDADO', 'Preparar flores e champanhe'),
(3, 3, '2026-11-08 08:30:00', 'AGENDADO', 'Configurar projetor multimídia');
