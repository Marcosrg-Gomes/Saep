# DICIONÁRIO COMPLETO DAS FUNÇÕES DO SISTEMA (SAEP SENAI)

Este documento foi criado especificamente para você entender **exatamente o que cada função faz**, **por que ela existe**, **onde é chamada** e **qual critério de avaliação do SAEP ela atende**.

---

## 1. MÓDULO: `db.py` (Acesso ao Banco de Dados MySQL)

Este módulo isola todos os comandos SQL para evitar vazamento de credenciais e ataques de SQL Injection.

### `query(sql, params=())`
- **O que faz:** Executa comandos `SELECT` no MySQL e devolve o resultado formatado como uma lista de dicionários Python (`[{"id": 1, "nome": "João"}, ...]`).
- **Ponto crítico:** Converte automaticamente campos do tipo `date` e `datetime` para strings no formato ISO (ex: `"2026-11-06T14:30:00"`), permitindo que sejam transformados em JSON sem dar erro no Flask.
- **Exemplo de uso:**
  ```python
  usuarios = query("SELECT id, nome FROM usuarios WHERE login = %s", (login,))
  ```

### `execute(sql, params=())`
- **O que faz:** Executa instruções que modificam o banco: `INSERT`, `UPDATE` e `DELETE`.
- **Ponto crítico:** Executa o `con.commit()` automaticamente para gravar as alterações de forma permanente no MySQL e retorna `cur.lastrowid` (o ID do registro recém-criado).
- **Exemplo de uso:**
  ```python
  novo_id = execute("INSERT INTO clientes (nome, cpf_hash) VALUES (%s, %s)", (nome, cpf_hash))
  ```

### `buscar_um(sql, params, mensagem)`
- **O que faz:** Executa um `SELECT` esperando apenas uma linha. Se a consulta vier vazia, lança um erro HTTP 404 com a mensagem personalizada.
- **Ponto crítico:** Evita que o sistema tente acessar `resultado[0]` e quebre com `IndexError`.

### `bloquear_se_existir(sql, params, mensagem)`
- **O que faz:** Executa um `SELECT` para verificar se já existe um registro (ex: Placa, IMEI, Microchip ou CPF). Se encontrar, lança um erro HTTP 409 (Conflito/Duplicidade).
- **Ponto crítico:** Garante a regra do SAEP de que identificadores únicos não podem se repetir.

### `testar_conexao()`
- **O que faz:** Roda `SELECT DATABASE(), VERSION()` para confirmar que o MySQL está respondendo e qual banco está ativo.

---

## 2. MÓDULO: `autenticacao.py` (Segurança, Bcrypt e Sessão)

Atende aos critérios de login seguro, LGPD e tempo de expiração da sessão.

### `gerar_hash(texto: str) -> str`
- **O que faz:** Recebe uma senha ou CPF em texto puro e gera um hash seguro usando o algoritmo `bcrypt` com salt dinâmico (`rounds=10`).
- **Critério SAEP:** Atende à regra da LGPD de nunca armazenar dados sensíveis em texto puro no banco de dados.

### `conferir(texto: str, hash_salvo: str) -> bool`
- **O que faz:** Compara o texto digitado pelo usuário com o hash salvo no MySQL usando `bcrypt.checkpw()`. Devolve `True` se a senha/CPF bater ou `False` se for inválido.
- **Importante:** Trata exceções para que hashes corrompidos não travem a aplicação.

### `autenticar(login: str, senha: str) -> dict`
- **O que faz:** Busca o usuário no MySQL pelo campo `login` e confere a senha.
- **Critério SAEP:** Em caso de erro, devolve mensagem genérica (*"Usuário ou senha inválidos"* com status 401), evitando que invasores descubram quais logins existem.

### `iniciar_sessao(usuario: dict)`
- **O que faz:** Salva na sessão do Flask (`session`) as variáveis: `usuario_id`, `nome` do usuário e `login_em` (o timestamp exato via `time.time()`).

### `logado() -> bool`
- **O que faz:** Verifica se existe um usuário na sessão E se o tempo decorrido desde o login não ultrapassou `EXPIRACAO_SEGUNDOS` (30 minutos = `30 * 60`).
- **Critério SAEP:** Se o tempo tiver expirado, limpa a sessão (`session.clear()`) e retorna `False`, forçando o redirecionamento para o login.

---

## 3. MÓDULO: `clientes.py` (Gestão de Clientes e Busca)

### `apenas_digitos(valor: str) -> str`
- **O que faz:** Remove pontos, traços e espaços, deixando apenas números (`"123.456.789-00"` vira `"12345678900"`).

### `cpf_valido(cpf: str) -> bool`
- **O que faz:** Valida se a string resultante tem exatamente 11 dígitos numéricos.

### `_cpf_ja_cadastrado(cpf: str, ignorar_id: int = 0) -> bool`
- **O que faz:** Como o hash `bcrypt` tem salt dinâmico, não dá para fazer `SELECT * WHERE cpf_hash = '...'`. Esta função percorre os clientes do banco e usa `conferir(cpf, r['cpf_hash'])`. Se bater e o ID for diferente de `ignorar_id`, acusa duplicidade.

### `listar(termo: str = "")`
- **O que faz:** Lista os clientes do sistema. Se o parâmetro `termo` for passado (ex: busca na barra de pesquisa):
  1. Filtra com `LIKE %termo%` por Nome, Telefone ou E-mail.
  2. Se o termo digitado tiver 11 números, faz a busca exata por CPF via hash matching.
- **Critério SAEP:** Atende à regra de busca dinâmica que atualiza a listagem na tela.

### `cadastrar(dados: dict)` e `editar(id_, dados: dict)`
- **O que faz:** Valida nome, e-mail e CPF, grava/atualiza no banco gerando o hash do CPF e retorna o objeto atualizado.

### `excluir(id_: int)`
- **O que faz:** Antes de deletar o cliente, confere se ele possui registros filhos (veículos, pets, contratos, etc.). Se possuir, bloqueia a exclusão com status 409.

---

## 4. MÓDULO: `agendamento.py` (Agendamentos e Ordenação por Data)

### `listar()`
- **O que faz:** Executa um `SELECT` com `JOIN` entre as 4 tabelas (Agendamento + Recurso Secundário + Cliente + Serviço).
- **Critério Mandatório do SAEP:** A consulta contém obrigatoriamente:
  ```sql
  ORDER BY a.data_agendamento ASC, a.id ASC
  ```
  Isso garante que os agendamentos mais próximos apareçam sempre primeiro.

### `cadastrar(dados: dict)`
- **O que faz:** Valida se o recurso intermediário e o serviço existem no banco, converte a string de data para objeto `datetime` e insere o agendamento com status padrão `'AGENDADO'`.

### `editar(id_, dados: dict)` (Reagendamento)
- **O que faz:** Permite que o usuário altere a data/horário e o status do agendamento, salvando a alteração no MySQL.
- **Critério SAEP:** Ao reagendar, a listagem se reordena automaticamente pela nova data.

---

## 5. MÓDULO: `rotas.py` (Controle de Requisições HTTP e Páginas)

### `@bp.before_request def verificar_autenticacao()`
- **O que faz:** É um filtro (middleware) que roda antes de qualquer rota.
  - Se a rota for pública (`/login`, `/api/login`, etc.) ou a função `logado()` for verdadeira: permite o acesso.
  - Se a sessão expirou e a requisição for de API: devolve JSON `{erro: "Sessão expirada"}`, status 401.
  - Se a requisição for de página HTML: redireciona para `/login?expirou=1`.

### `@bp.get("/api/me")`
- **O que faz:** Devolve em JSON o nome do usuário armazenado na sessão (`session["nome"]`).
- **Critério SAEP:** É consumido pelo JavaScript da tela principal para exibir `"Usuário: Administrador"` no topo.

### CRUD Genérico: `colecao(recurso)` e `elemento(recurso, id_)`
- **O que faz:** Roteia dinamicamente chamadas `GET`, `POST`, `PUT`, `DELETE` para o arquivo correspondente (`clientes.py`, `pets.py`, `agendamento.py`), economizando dezenas de linhas de código repetido.

---

## 6. MÓDULO FRONT-END: `app.js` (JavaScript Puro do Navegador)

### `api(url, metodo, corpo)`
- **O que faz:** Faz requisições assíncronas com `fetch()`, envia headers JSON e cookies de sessão (`credentials: "same-origin"`). Se a API responder 401 (sessão expirada), redireciona o navegador na hora para a tela de login.

### `lerCampos(campos)`
- **O que faz:** Lê um array de IDs de inputs HTML e monta um objeto JavaScript pronto para enviar à API (ex: `{"nome": "Maria", "cpf": "..."}`).

### `preencher(campos, dados)`
- **O que faz:** Pega os dados vindos da tabela e joga nos inputs do formulário para permitir a edição de um registro com apenas 1 clique.
