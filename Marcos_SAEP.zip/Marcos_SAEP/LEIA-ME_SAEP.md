# RESUMO E GUIA DE APLICAÇÃO - PROVA PRÁTICA SAEP SENAI

Todos os modelos, documentações e códigos corrigidos foram gerados na pasta:
`c:\Users\Dev_2o_Ano\Downloads\SAEP`

---

## 1. O que foi gerado nesta pasta:

1. **`00_DOCUMENTACAO_BASE/`**:

   - `GUIA_PROVA_PRATICA_SAEP.md`: Checklist completo com a matriz de critérios de correção do SENAI e lista de armadilhas.
   - `DOCUMENTACAO_SOFTWARE_BASE.md`: Modelo pronto do Anexo 1 exigido na Entrega 1 (Requisitos Funcionais RF01 a RF08, Infraestrutura e Diagrama Entidade-Relacionamento).
2. **`TEMA_1_PETSHOP_CLINICA/`**:

   - Sistema completo funcional para Pet Shop e Clínica Veterinária.
   - Banco de dados `petshop_db.sql` com 3+ registros em todas as tabelas.
   - Proteção LGPD com hashing bcrypt de CPF, expiração de sessão e ordenação cronológica de agendamentos.
3. **`TEMA_2_ACADEMIA_AVALIACOES/`**:

   - Script SQL `academia_db.sql` com mínimo de 3 registros por tabela.
   - Tema focado em Alunos (Clientes), Matrículas (Recurso Secundário) e Avaliações Físicas (Agendamentos).
4. **`TEMA_3_BIBLIOTECA_LOCACOES/`**:

   - Script SQL `biblioteca_db.sql` com mínimo de 3 registros por tabela.
   - Tema focado em Leitores (Clientes), Obras/ISBN (Recurso Secundário) e Empréstimos/Reservas (Agendamentos).

---

## 2. Passo a Passo Rápido na Hora da Prova:

1. **Configurar o Banco MySQL**:
   ```powershell
   mysql -u root -p < petshop_db.sql
   ```
2. **Instalar Dependências e Executar**:
   ```powershell
   pip install flask bcrypt mysql-connector-python
   python testar_conexao.py
   python app.py
   ```
3. **Acessar**:
   - URL: `http://localhost:5000`
   - Usuário: `admin` | Senha: `admin123`
