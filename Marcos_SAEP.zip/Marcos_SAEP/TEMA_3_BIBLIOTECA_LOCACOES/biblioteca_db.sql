-- ====================================================================
-- Script: biblioteca_db.sql | MySQL 8+
-- Tema: Sistema de Biblioteca / Locadora (Livros & Empréstimos)
-- Atende a todas as exigências do SAEP SENAI (mínimo 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS biblioteca_db;
CREATE DATABASE biblioteca_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE biblioteca_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recurso Secundário: Livros / Obras do Acervo
CREATE TABLE IF NOT EXISTS livros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,                  -- Leitor com reserva preferencial / Solicitante
  isbn VARCHAR(20) NOT NULL UNIQUE,        -- Identificador Único do Livro
  titulo VARCHAR(120) NOT NULL,
  autor VARCHAR(100) NOT NULL,
  ano_publicacao INT,
  categoria VARCHAR(50),
  CONSTRAINT fk_livro_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  livro_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_livro FOREIGN KEY (livro_id) REFERENCES livros(id),
  CONSTRAINT fk_ag_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Bibliotecário Chefe', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Fernanda Auxiliar', 'fernanda', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Gabriel Suporte', 'gabriel', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Renata Silveira', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-4444', 'renata@email.com', 'Rua dos Livros, 10'),
('Tiago Ramos', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-5555', 'tiago@email.com', 'Av. Central, 90'),
('Larissa Dias', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-6666', 'larissa@email.com', 'Rua das Letras, 300');

INSERT INTO livros (cliente_id, isbn, titulo, autor, ano_publicacao, categoria) VALUES
(1, '9788535902778', 'Dom Casmurro', 'Machado de Assis', 1899, 'Literatura Clássica'),
(2, '9788575420584', 'O Pequeno Príncipe', 'Antoine de Saint-Exupéry', 1943, 'Fábula'),
(3, '9788532511010', 'Harry Potter e a Pedra Filosofal', 'J.K. Rowling', 1997, 'Fantasia');

INSERT INTO servicos (descricao, valor) VALUES
('Empréstimo Domiciliar (15 dias)', 0.00),
('Reserva Especial de Obra Rara', 15.00),
('Restauração e Encadernação', 35.00);

INSERT INTO agendamentos (livro_id, servico_id, data_agendamento, status, observacao) VALUES
(2, 1, '2026-11-06 11:00:00', 'AGENDADO', 'Devolução prevista em 15 dias'),
(1, 2, '2026-11-07 14:00:00', 'AGENDADO', 'Retirar no balcão principal'),
(3, 3, '2026-11-08 10:00:00', 'AGENDADO', 'Higienização de capa');
