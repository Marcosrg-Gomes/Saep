-- ====================================================================
-- Script: academia_db.sql | MySQL 8+
-- Tema: Gestão de Academia e Avaliações Físicas / Treinos
-- Atende a todas as exigências do SAEP SENAI (mínimo 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS academia_db;
CREATE DATABASE academia_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE academia_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recurso Secundário: Matrículas / Planos de Treino do Aluno
CREATE TABLE IF NOT EXISTS matriculas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  codigo_matricula VARCHAR(20) NOT NULL UNIQUE,
  plano VARCHAR(50) NOT NULL,                  -- Mensal, Semestral, Anual VIP
  objetivo VARCHAR(100) NOT NULL,              -- Hipertrofia, Emagrecimento, Condicionamento
  data_inicio DATE NOT NULL,
  observacao VARCHAR(255),
  CONSTRAINT fk_mat_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  matricula_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_mat FOREIGN KEY (matricula_id) REFERENCES matriculas(id),
  CONSTRAINT fk_ag_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

-- Registros obrigatórios (3 por tabela)
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Coordenador Fit', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Prof. Personal Felipe', 'felipe', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Mariana Recepção', 'mariana', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Lucas Henrique', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-1111', 'lucas@fit.com', 'Rua Central, 50'),
('Juliana Paes', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-2222', 'juliana@fit.com', 'Av. das Nações, 1500'),
('Mateus Costa', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-3333', 'mateus@fit.com', 'Rua 7 de Setembro, 32');

INSERT INTO matriculas (cliente_id, codigo_matricula, plano, objetivo, data_inicio, observacao) VALUES
(1, 'MAT-2026-001', 'Anual VIP', 'Hipertrofia e Força', '2026-01-10', 'Acompanhamento nutricional incluso'),
(2, 'MAT-2026-002', 'Semestral', 'Emagrecimento', '2026-02-15', 'Evitar impacto no joelho direito'),
(3, 'MAT-2026-003', 'Mensal', 'Condicionamento Físico', '2026-03-01', 'Treinos no período noturno');

INSERT INTO servicos (descricao, valor) VALUES
('Bioimpedância e Avaliação Física', 90.00),
('Sessão Personal Trainer Individual', 120.00),
('Montagem de Ficha e Treino Periodizado', 75.00);

INSERT INTO agendamentos (matricula_id, servico_id, data_agendamento, status, observacao) VALUES
(2, 1, '2026-11-06 17:00:00', 'AGENDADO', 'Primeira reavaliação de medidas'),
(1, 2, '2026-11-07 08:00:00', 'AGENDADO', 'Foco em membros superiores'),
(3, 3, '2026-11-08 19:30:00', 'AGENDADO', 'Atualizar treino para série B');
