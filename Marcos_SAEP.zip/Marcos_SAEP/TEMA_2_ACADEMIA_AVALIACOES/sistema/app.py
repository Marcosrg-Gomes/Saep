"""
Servidor Principal da Aplicação Flask
"""
import os
from flask import Flask
from rotas import bp

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "chave-secreta-saep-senai-2026")

app.register_blueprint(bp)

if __name__ == "__main__":
    print("Iniciando Sistema de Pet Shop na porta 5000...")
    print("Acesse no navegador: http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
