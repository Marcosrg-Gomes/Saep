"""Servidor Flask da aplicação do Pet Shop."""
import os
import sys

DIRETORIO_ATUAL = os.path.dirname(os.path.abspath(__file__))
if DIRETORIO_ATUAL not in sys.path:
    sys.path.insert(0, DIRETORIO_ATUAL)

from flask import Flask
from rotas import bp

app = Flask(
    __name__,
    static_folder=os.path.join(DIRETORIO_ATUAL, "static"),
    template_folder=os.path.join(DIRETORIO_ATUAL, "templates")
)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "chave-secreta-saep-senai-2026")

app.register_blueprint(bp)

if __name__ == "__main__":
    print("==================================================")
    print("  SISTEMA PET SHOP & CLÍNICA VETERINÁRIA (SENAI)")
    print("  Acesse: http://localhost:5000")
    print("  Login: admin | Senha: admin123")
    print("==================================================")
    app.run(host="0.0.0.0", port=5000, debug=True)
