-- ====================================================================
-- Script: petshop_db.sql | MySQL 8+
-- Banco do Sistema Pet Shop & Clínica Veterinária
-- ====================================================================

DROP DATABASE IF EXISTS petshop_db;
CREATE DATABASE petshop_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE petshop_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,              -- CPF criptografado com bcrypt (LGPD)
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,                 -- Vínculo com o tutor (vários pets para 1 dono)
  chip VARCHAR(30) NOT NULL UNIQUE,        -- Microchip / Identificador único
  nome VARCHAR(50) NOT NULL,
  especie VARCHAR(30) NOT NULL,            -- Canino, Felino, etc.
  raca VARCHAR(50) NOT NULL,
  porte VARCHAR(20),                       -- Pequeno, Médio, Grande
  observacao VARCHAR(255),
  CONSTRAINT fk_pet_tutor FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pet_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_pet FOREIGN KEY (pet_id) REFERENCES pets(id),
  CONSTRAINT fk_ag_servico FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

-- Senhas de teste: admin/admin123 | carlos/carlos123 | ana/ana12345
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Dr. Roberto Admin', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Carlos Veterinário', 'carlos', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Ana Recepção', 'ana', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

-- Tutores (CPFs válidos com hash bcrypt): 529.982.247-25 | 111.444.777-35 | 390.533.447-05
INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('João da Silva', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-1111', 'joao@email.com', 'Rua das Flores, 100 - São Paulo/SP'),
('Maria Oliveira', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-2222', 'maria@email.com', 'Av. Paulista, 2000 - São Paulo/SP'),
('Pedro Santos', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-3333', 'pedro@email.com', 'Rua Augusta, 350 - São Paulo/SP');

-- Pets (Tutor 1 tem 2 animais: Thor e Pipoca)
INSERT INTO pets (cliente_id, chip, nome, especie, raca, porte, observacao) VALUES
(1, 'CHIP-98101', 'Thor', 'Canino', 'Golden Retriever', 'Grande', 'Dócil e amigável'),
(1, 'CHIP-98102', 'Pipoca', 'Canino', 'Poodle Toy', 'Pequeno', 'Pele sensível'),
(2, 'CHIP-98201', 'Mimi', 'Felino', 'Siamês', 'Pequeno', 'Gata calma'),
(3, 'CHIP-98301', 'Bob', 'Canino', 'Bulldog Francês', 'Médio', 'Alérgico a picada de pulga');

INSERT INTO servicos (descricao, valor) VALUES
('Banho e Tosa Completa', 85.00),
('Consulta Veterinária', 150.00),
('Aplicação de Vacina', 110.00);

INSERT INTO agendamentos (pet_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 14:00:00', 'AGENDADO', 'Tosa higiênica e corte de unhas'),
(3, 2, '2026-11-07 09:30:00', 'AGENDADO', 'Check-up de rotina'),
(2, 3, '2026-11-08 11:00:00', 'AGENDADO', 'Trazer carteira de vacinação');
