from db import testar_conexao

try:
    info = testar_conexao()
    print("==================================================")
    print("  SUCESSO: Conexão OK com MySQL!")
    print(f"  Banco ativo:  {info.get('banco')}")
    print(f"  Versão MySQL: {info.get('versao')}")
    print("==================================================")
except Exception as e:
    print("==================================================")
    print("  ERRO AO CONECTAR NO MYSQL:")
    print("  ", e)
    print("==================================================")
