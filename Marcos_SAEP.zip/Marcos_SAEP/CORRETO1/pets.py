"""Regras de pets. Todo pet pertence a um tutor já cadastrado."""
from db import ErroNegocio, bloquear_se_existir, buscar_um, execute, query

SELECT = """
    SELECT
        p.id,
        p.cliente_id,
        c.nome AS cliente_nome,
        p.chip,
        p.nome,
        p.especie,
        p.raca,
        p.porte,
        p.observacao
    FROM pets p
    JOIN clientes c ON c.id = p.cliente_id
"""


def _inteiro(valor, mensagem):
    try:
        return int(valor)
    except (TypeError, ValueError):
        raise ErroNegocio(mensagem)


def _validar(d, id_=0):
    chip = (d.get("chip") or "").strip()
    nome = (d.get("nome") or "").strip()
    especie = (d.get("especie") or "").strip()
    raca = (d.get("raca") or "").strip()
    porte = (d.get("porte") or "").strip()
    observacao = (d.get("observacao") or "").strip()

    if not chip:
        raise ErroNegocio("Informe o microchip ou identificador do pet.")
    if not nome:
        raise ErroNegocio("Informe o nome do pet.")
    if not especie:
        raise ErroNegocio("Informe a espécie do animal.")
    if not raca:
        raise ErroNegocio("Informe a raça.")

    cliente_id = _inteiro(d.get("cliente_id"), "Selecione o tutor responsável pelo pet.")
    buscar_um("SELECT id FROM clientes WHERE id = %s", (cliente_id,), "O tutor informado não está cadastrado.")
    bloquear_se_existir("SELECT id FROM pets WHERE chip = %s AND id <> %s", (chip, id_), "Microchip já cadastrado.")
    return cliente_id, chip, nome, especie, raca, porte, observacao


def listar():
    return query(SELECT + "ORDER BY c.nome, p.nome")


def obter(id_):
    return buscar_um(SELECT + "WHERE p.id = %s", (id_,), "Pet não encontrado.")


def cadastrar(d):
    return obter(execute("INSERT INTO pets (cliente_id, chip, nome, especie, raca, porte, observacao) "
                         "VALUES (%s,%s,%s,%s,%s,%s,%s)", _validar(d)))


def editar(id_, d):
    obter(id_)
    execute("UPDATE pets SET cliente_id=%s, chip=%s, nome=%s, especie=%s, raca=%s, porte=%s, observacao=%s WHERE id=%s",
            (*_validar(d, id_), id_))
    return obter(id_)


def excluir(id_):
    obter(id_)
    bloquear_se_existir("SELECT id FROM agendamentos WHERE pet_id = %s", (id_,),
                        "Pet possui agendamentos. Exclua-os antes.")
    execute("DELETE FROM pets WHERE id = %s", (id_,))
