-- ====================================================================
-- Script: petshop_db.sql | MySQL 8+
-- Tema: Pet Shop & Clínica Veterinária
-- Atende a todas as exigências do SAEP SENAI (mínimo 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS petshop_db;
CREATE DATABASE petshop_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE petshop_db;

-- 1. TABELA DE USUÁRIOS DO SISTEMA
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,            -- Hash bcrypt
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. TABELA DE CLIENTES (TUTORES)
CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,              -- CPF criptografado com bcrypt (LGPD)
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. TABELA DE RECURSO SECUNDÁRIO (PETS)
CREATE TABLE IF NOT EXISTS pets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,                 -- Vínculo obrigatório ao cliente (Tutor)
  chip VARCHAR(20) NOT NULL UNIQUE,        -- Microchip / Identificador Único
  nome VARCHAR(50) NOT NULL,
  especie VARCHAR(30) NOT NULL,            -- Cachorro, Gato, Ave, etc.
  raca VARCHAR(50) NOT NULL,
  porte VARCHAR(20),                       -- Pequeno, Médio, Grande
  observacao VARCHAR(255),                 -- Ex: alérgico, dócil, bravo
  CONSTRAINT fk_pet_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- 4. TABELA DE SERVIÇOS
CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

-- 5. TABELA DE AGENDAMENTOS
CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pet_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_pet FOREIGN KEY (pet_id) REFERENCES pets(id),
  CONSTRAINT fk_ag_servico FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

-- ====================================================================
-- POPULAÇÃO INICIAL (MÍNIMO DE 3 REGISTROS POR TABELA)
-- ====================================================================

-- Senhas de teste: admin/admin123 | veterinario/vet123 | recepcao/rec123
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Dr. Roberto Admin', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Dra. Camila Santos', 'camila', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Lucas Recepção', 'lucas', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

-- Tutores (CPFs de teste válidos com hash): 529.982.247-25 | 111.444.777-35 | 390.533.447-05
INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Ana Clara Lima', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-1010', 'anaclara@email.com', 'Rua das Palmeiras, 120 - SP'),
('Bruno Albuquerque', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-2020', 'bruno@email.com', 'Av. Brasil, 450 - SP'),
('Carla Mendes', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-3030', 'carla@email.com', 'Rua dos Pinheiros, 78 - SP');

-- Pets vinculados
INSERT INTO pets (cliente_id, chip, nome, especie, raca, porte, observacao) VALUES
(1, '981098123456789', 'Thor', 'Canino', 'Golden Retriever', 'Grande', 'Muito amigável e dócil'),
(2, '981098987654321', 'Mimi', 'Felino', 'Siamês', 'Pequeno', 'Assustada com barulhos altos'),
(3, '981098112233445', 'Pipoca', 'Canino', 'Poodle Toy', 'Pequeno', 'Pele sensível para shampoo');

-- Serviços oferecidos
INSERT INTO servicos (descricao, valor) VALUES
('Consulta Veterinária de Rotina', 160.00),
('Banho e Tosa Completa', 95.00),
('Aplicação de Vacina V10', 120.00);

-- Agendamentos ordenados por data
INSERT INTO agendamentos (pet_id, servico_id, data_agendamento, status, observacao) VALUES
(2, 2, '2026-11-06 14:00:00', 'AGENDADO', 'Utilizar secador morno'),
(1, 1, '2026-11-07 10:30:00', 'AGENDADO', 'Check-up semestral'),
(3, 3, '2026-11-08 16:00:00', 'AGENDADO', 'Trazer carteirinha de vacinação');
