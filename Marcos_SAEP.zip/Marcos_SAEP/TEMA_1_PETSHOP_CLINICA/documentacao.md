# ANEXO 1 - DOCUMENTAÇÃO DE SOFTWARE
## Sistema de Agendamentos para Pet Shop e Clínica Veterinária

**Estudante:** [Seu Nome Completo]  
**Data:** [Data da Prova]  
**Número da Prova:** 1  

---

### ENTREGA 01: Documentação de Software

#### 1.1 Tabela de Requisitos Funcionais do Sistema

| ID | Requisito | Descrição |
|:---|:---|:---|
| **RF01** | Autenticação e Sessão | Permitir que atendentes e veterinários acessem o sistema com usuário e senha. Se as credenciais estiverem incorretas, exibir mensagem de erro genérica. A sessão expira após 30 minutos de inatividade. |
| **RF02** | Proteção de Dados (LGPD) | O CPF dos tutores/clientes é gravado no banco como hash `bcrypt`, não sendo exposto em texto puro em nenhuma hipótese. |
| **RF03** | Painel Principal | Exibir no topo o nome do profissional logado, atalhos de navegação para Tutores, Pets e Consultas/Agendamentos, além do botão de encerramento da sessão (Sair). |
| **RF04** | Gestão de Tutores (Clientes) | Cadastro, edição e listagem de tutores. Inclui campo de busca textual em tempo real por nome, e-mail, telefone ou busca exata por CPF via hash matching. |
| **RF05** | Cadastro de Pets com Vínculo | Cada Pet cadastrado (nome, espécie, raça, número do microchip) deve obrigatoriamente pertencer a um tutor já cadastrado. O número do microchip é chave única (UNIQUE). |
| **RF06** | Listagem de Agendamentos Ordenada | A tela de consultas/banhos deve listar todos os agendamentos **ordenados de forma crescente por data e hora**, trazendo o nome do tutor, os dados do pet e o serviço contratado. |
| **RF07** | Reagendamento | Possibilidade de editar e reagendar uma consulta existente, alterando a data/hora e o status (AGENDADO, EM_ANDAMENTO, CONCLUIDO, CANCELADO). |
| **RF08** | Regras de Exclusão Segura | Impedir exclusão de tutores com pets cadastrados e de pets com consultas ativas. |

#### 1.2 Requisitos de Infraestrutura

- **SGBD Utilizado:** MySQL  
- **Versão:** 8.0 ou superior  
- **Linguagem de Programação:** Python  
- **Versão:** 3.10 ou superior  
- **Framework Web:** Flask 3.x  
- **Bibliotecas:** `mysql-connector-python`, `bcrypt`
