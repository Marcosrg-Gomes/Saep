# COLA RÁPIDA & SNIPPETS PARA A HORA DA PROVA (SAEP SENAI)

Este arquivo foi feito para você consultar rapidamente durante a prova caso dê um "branco" na sintaxe ou nas regras.

---

## 1. SNIPPETS DE BACKEND (PYTHON / FLASK)

### A) Criar Hash Bcrypt e Verificar Senha / CPF:
```python
import bcrypt

# Gerar hash com salt (para senhas ou CPF - LGPD)
hash_gerado = bcrypt.hashpw("admin123".encode('utf-8'), bcrypt.gensalt(10)).decode('utf-8')

# Conferir se bate (retorna True ou False)
senha_correta = bcrypt.checkpw("admin123".encode('utf-8'), hash_gerado.encode('utf-8'))
```

### B) Proteção de Sessão com Expiração Automática (30 min):
```python
import time
from flask import session, redirect, jsonify, request

EXPIRACAO = 30 * 60  # 30 minutos em segundos

def logado():
    if "usuario_id" in session:
        # Se o tempo desde o login for menor que 30 min, a sessão é válida
        if time.time() - session.get("login_em", 0) <= EXPIRACAO:
            return True
    session.clear()
    return False

# Middleware que intercepta todas as rotas
@bp.before_request
def checar():
    rotas_publicas = ("/", "/login", "/api/login")
    if request.path in rotas_publicas or logado():
        return None
    if request.path.startswith("/api/"):
        return jsonify(erro="Sessão expirada"), 401
    return redirect("/login?expirou=1")
```

### C) Consulta SQL Padrão com Dicionário:
```python
import mysql.connector

CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "Senai@118",
    "database": "nome_do_banco"
}

def query(sql, params=()):
    with mysql.connector.connect(**CONFIG) as con, con.cursor(dictionary=True) as cur:
        cur.execute(sql, params)
        return cur.fetchall()

def execute(sql, params=()):
    with mysql.connector.connect(**CONFIG) as con, con.cursor() as cur:
        cur.execute(sql, params)
        con.commit()
        return cur.lastrowid
```

---

## 2. SNIPPETS DE BANCO DE DADOS (MYSQL 8+)

### A) Script Limpo com Chaves Estrangeiras e Enums:
```sql
DROP DATABASE IF EXISTS saep_db;
CREATE DATABASE saep_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE saep_db;

-- Tabela Usuários (Login)
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela Clientes (CPF LGPD)
CREATE TABLE clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela Secundária (com Chave Estrangeira e Identificador Único)
CREATE TABLE itens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  codigo_identificador VARCHAR(50) NOT NULL UNIQUE,
  detalhe VARCHAR(100) NOT NULL,
  CONSTRAINT fk_item_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Tabela de Serviços / Preços
CREATE TABLE servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

-- Tabela Agendamentos (com Chaves Estrangeiras e Ordenação por Data)
CREATE TABLE agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_item FOREIGN KEY (item_id) REFERENCES itens(id),
  CONSTRAINT fk_ag_servico FOREIGN KEY (servico_id) REFERENCES servicos(id)
);
```

### B) Hashes Bcrypt Prontos para Inserir no SQL (Evita Erro na Prova):
| Valor Original | Hash Bcrypt Compatível ($2b$10$...) |
|:---|:---|
| `admin123` | `$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO` |
| `carlos123` | `$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK` |
| `ana12345` | `$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO` |
| `529.982.247-25` | `$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W` |
| `111.444.777-35` | `$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG` |
| `390.533.447-05` | `$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K` |

---

## 3. CHECKLIST FINAL ANTES DE ENTREGAR A PROVA

- [ ] Todas as tabelas do banco têm pelo menos **3 registros inseridos**?
- [ ] A tela de agendamentos está ordenada por **data crescente** (`ORDER BY data_agendamento ASC`)?
- [ ] A tela principal exibe o **nome do usuário logado** e tem o botão **Sair**?
- [ ] A busca de clientes funciona ao digitar um termo e atualiza a tabela?
- [ ] O CPF não está gravado como texto puro no banco?
- [ ] A documentação (`documentacao.pdf` ou `.docx`) contém todos os Requisitos Funcionais (**RF1 a RF8**) e os dados de infraestrutura preenchidos?
- [ ] O arquivo final `.zip` na Área de Trabalho contém: `documentacao.pdf`, `der.png`, `banco.sql` e a pasta `sistema/`?
