# GUIA MESTRE DE COMANDOS - PROVA PRÁTICA SAEP SENAI

Este arquivo reúne todos os comandos que você pode precisar usar no PowerShell ou Prompt de Comando durante a prova prática.

---

## 1. Comandos Essenciais do MySQL (Com Senha)

A senha padrão configurada nas máquinas do SENAI é **`Senai@118`** (ou `root`).

### Como importar o arquivo `.sql` no MySQL:

#### Opção A (Direto no Terminal com senha):
```powershell
# Sintaxe: mysql -u root -p<SUA_SENHA> < caminho_do_arquivo.sql
# ATENÇÃO: Entre o -p e a senha NÃO tem espaço!

# Exemplo com a senha padrão do SENAI:
mysql -u root -pSenai@118 < petshop_db.sql

# Ou se pedir a senha interativa:
mysql -u root -p < petshop_db.sql
# (Quando apertar Enter, digite: Senai@118)
```

#### Opção B (Se você estiver dentro da pasta `sistema/`):
```powershell
mysql -u root -pSenai@118 < petshop_db.sql
```

#### Opção C (Entrando direto no prompt do MySQL):
```powershell
# 1. Conecta no MySQL:
mysql -u root -pSenai@118

# 2. Já dentro do MySQL (mysql>), rode:
source petshop_db.sql;

# 3. Conferir se criou o banco e as tabelas:
SHOW DATABASES;
USE petshop_db;
SHOW TABLES;
SELECT COUNT(*) FROM clientes;
SELECT COUNT(*) FROM servicos;
SELECT COUNT(*) FROM agendamentos;

# 4. Sair do MySQL:
EXIT;
```

---

## 2. Como Rodar o Sistema (Fora ou Dentro da Pasta `sistema`)

Você pode rodar de **dois jeitos** dependendo de onde o seu terminal estiver aberto:

### JEITO 1: Se o seu terminal estiver na pasta RAIZ do tema (ex: `C:\...\TEMA_1_PETSHOP_CLINICA>`):
```powershell
# Testar a conexão com o banco:
python sistema\testar_conexao.py

# Iniciar o servidor web:
python sistema\app.py
```

### JEITO 2: Entrando na pasta `sistema/` (Modo Recomendado):
```powershell
cd sistema

# Testar a conexão:
python testar_conexao.py

# Iniciar o servidor:
python app.py
```

Quando aparecer no terminal:
`* Running on http://127.0.0.1:5000`
Abra o seu navegador (Chrome/Edge) e acesse:
👉 **`http://localhost:5000`**

---

## 3. Comandos de Verificação e Instalação de Pacotes

Se a máquina da prova for limpa ou reiniciar:
```powershell
# Instalar todas as dependências necessárias:
pip install flask bcrypt mysql-connector-python

# Ou pelo arquivo requirements.txt:
pip install -r sistema\requirements.txt
```

---

## 4. O que Fazer se a Conexão com o Banco Falhar?

1. Verifique se o serviço do MySQL está rodando no Windows:
```powershell
# Ver status do serviço do MySQL:
Get-Service MySQL80

# Se estiver parado (Stopped), inicie com:
Start-Service MySQL80
```

2. Se a senha da máquina for diferente de `Senai@118`:
Abra o arquivo `sistema/db.py` e altere a linha 11:
```python
"password": os.getenv("DB_PASSWORD", "SUA_SENHA_AQUI"),
```
Ou defina uma variável de ambiente no PowerShell:
```powershell
$env:DB_PASSWORD="sua_senha"
```

---

## 5. Como Gerar o Arquivo Final para Entrega (`SeuNome.zip`)

No final da prova, o professor pede uma pasta zipada na Área de Trabalho com o seu nome:
```powershell
# Exemplo de comando PowerShell para compactar a entrega:
Compress-Archive -Path sistema, documentacao.pdf, petshop_db.sql -DestinationPath "$HOME\Desktop\SeuNomeCompleto.zip"
```
Ou simplesmente:
1. Selecione os arquivos: `documentacao.pdf` (ou docx), `der.png` (ou pdf), `banco.sql` e a pasta `sistema`.
2. Clique com botão direito > **Enviar para** > **Pasta compactada (zip)**.
3. Renomeie para **`SeuNomeCompleto.zip`**.
