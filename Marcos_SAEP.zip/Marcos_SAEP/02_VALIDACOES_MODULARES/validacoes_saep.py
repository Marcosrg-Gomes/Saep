"""
=============================================================================
PACOTE COMPLETO DE VALIDAÇÕES PARA PROVAS PRÁTICAS DO SAEP SENAI
Contém todas as funções de validação mais cobradas pelos avaliadores,
com comentários detalhados e mensagens de erro prontas.
=============================================================================
"""
import re
from datetime import date, datetime


class ErroValidacao(Exception):
    """Exceção levantada quando algum campo não atende aos critérios do SAEP."""
    def __init__(self, mensagem, status=400):
        super().__init__(mensagem)
        self.mensagem = mensagem
        self.status = status


# =============================================================================
# 1. VALIDAÇÃO DE CPF (OFICIAL E COM DÍGITOS VERIFICADORES)
# =============================================================================

def apenas_digitos(texto: str) -> str:
    """Remove qualquer caractere não numérico (pontos, traços, barras)."""
    return re.sub(r"\D", "", texto or "")


def validar_cpf_completo(cpf: str) -> str:
    """
    Validação real de CPF (cálculo dos 2 dígitos verificadores).
    Rejeita CPFs com menos de 11 dígitos ou números repetidos (111.111.111-11).
    Retorna apenas os 11 dígitos limpos.
    """
    cpf_limpo = apenas_digitos(cpf)

    if len(cpf_limpo) != 11:
        raise ErroValidacao("CPF inválido: deve conter exatamente 11 dígitos numéricos.")

    # Rejeita sequências repetidas conhecidas
    if cpf_limpo in [str(i) * 11 for i in range(10)]:
        raise ErroValidacao("CPF inválido: número repetido não permitido.")

    # Cálculo do 1º Dígito Verificador
    soma_1 = sum(int(cpf_limpo[i]) * (10 - i) for i in range(9))
    resto_1 = (soma_1 * 10) % 11
    digito_1 = 0 if resto_1 == 10 else resto_1

    if int(cpf_limpo[9]) != digito_1:
        raise ErroValidacao("CPF inválido: dígito verificador incorreto.")

    # Cálculo do 2º Dígito Verificador
    soma_2 = sum(int(cpf_limpo[i]) * (11 - i) for i in range(10))
    resto_2 = (soma_2 * 10) % 11
    digito_2 = 0 if resto_2 == 10 else resto_2

    if int(cpf_limpo[10]) != digito_2:
        raise ErroValidacao("CPF inválido: dígito verificador incorreto.")

    return cpf_limpo


# =============================================================================
# 2. VALIDAÇÃO DE PLACA VEICULAR (PADRÃO ANTIGO E MERCOSUL)
# =============================================================================

def validar_placa(placa: str) -> str:
    """
    Valida placas de veículos:
    - Padrão Antigo: ABC-1234 ou ABC1234
    - Padrão Mercosul: ABC1D23 ou ABC12D3
    """
    placa_limpa = (placa or "").upper().replace("-", "").strip()

    # Expressão regular cobrindo ambos os formatos
    padrao = r"^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$"
    if not re.fullmatch(padrao, placa_limpa):
        raise ErroValidacao("Placa inválida. Exemplos válidos: ABC1D23 ou ABC1234.")

    return placa_limpa


# =============================================================================
# 3. VALIDAÇÃO DE IMEI (CELULARES E TABLETS)
# =============================================================================

def validar_imei(imei: str) -> str:
    """
    Valida número de IMEI para assistência de celulares (15 dígitos exatos).
    """
    imei_limpo = apenas_digitos(imei)
    if len(imei_limpo) != 15:
        raise ErroValidacao("IMEI inválido: deve conter exatamente 15 dígitos numéricos.")
    return imei_limpo


# =============================================================================
# 4. VALIDAÇÃO DE MICROCHIP / IDENTIFICADOR ANIMAL (PET SHOP)
# =============================================================================

def validar_microchip(chip: str) -> str:
    """
    Valida código de microchip pet (ISO 11784/11785 - 15 dígitos numéricos ou alfanumérico limpo).
    """
    chip_limpo = apenas_digitos(chip)
    if len(chip_limpo) < 8 or len(chip_limpo) > 15:
        raise ErroValidacao("Microchip inválido: deve conter entre 8 e 15 dígitos.")
    return chip_limpo


# =============================================================================
# 5. VALIDAÇÃO DE E-MAIL E TELEFONE
# =============================================================================

def validar_email(email: str, obrigatorio: bool = False) -> str:
    """Valida formato padrão de e-mail (nome@dominio.com)."""
    email_limpo = (email or "").strip().lower()

    if not email_limpo:
        if obrigatorio:
            raise ErroValidacao("Informe um endereço de e-mail.")
        return ""

    padrao = r"^[\w\.-]+@[\w\.-]+\.\w{2,}$"
    if not re.fullmatch(padrao, email_limpo):
        raise ErroValidacao("Formato de e-mail inválido. Exemplo: usuario@provedor.com")

    return email_limpo


def validar_telefone(telefone: str, obrigatorio: bool = False) -> str:
    """Valida telefone fixo ou celular com DDD (10 ou 11 dígitos)."""
    tel_limpo = apenas_digitos(telefone)

    if not tel_limpo:
        if obrigatorio:
            raise ErroValidacao("Informe o número de telefone com DDD.")
        return ""

    if len(tel_limpo) not in (10, 11):
        raise ErroValidacao("Telefone inválido: informe o DDD + 8 ou 9 dígitos.")

    return tel_limpo


# =============================================================================
# 6. VALIDAÇÃO DE DATA E HORA DE AGENDAMENTO
# =============================================================================

def validar_data_agendamento(data_texto: str, permitir_passado: bool = False) -> datetime:
    """
    Converte datas recebidas de campos HTML datetime-local (ex: 2026-11-06T14:30)
    e garante que o formato esteja correto.
    """
    if not data_texto:
        raise ErroValidacao("Informe a data e horário do agendamento.")

    try:
        # Trata formato ISO vindo do JavaScript ou do input datetime-local
        data_limpa = data_texto.replace("Z", "").replace(" ", "T")
        data_obj = datetime.fromisoformat(data_limpa)
    except ValueError:
        raise ErroValidacao("Formato de data/hora inválido. Use AAAA-MM-DD HH:MM.")

    if not permitir_passado and data_obj < datetime.now():
        raise ErroValidacao("A data de agendamento não pode ser retroativa (no passado).")

    return data_obj


# =============================================================================
# 7. VALIDAÇÃO DE ANO DE FABRICAÇÃO / VEÍCULO / PRODUTO
# =============================================================================

def validar_ano(ano_valor, ano_minimo: int = 1950) -> int:
    """Garante ano numérico dentro de um intervalo realista."""
    try:
        ano = int(ano_valor)
    except (TypeError, ValueError):
        raise ErroValidacao("Informe um ano válido numérico.")

    ano_limite = date.today().year + 1
    if not (ano_minimo <= ano <= ano_limite):
        raise ErroValidacao(f"O ano deve estar entre {ano_minimo} e {ano_limite}.")

    return ano
