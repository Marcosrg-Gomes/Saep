# ANEXO 1 - DOCUMENTAÇÃO DE SOFTWARE (MODELO BASE SAEP)

**Estudante:** [Seu Nome Completo Aqui]  
**Data:** [Data de Hoje]  
**Número da Prova:** 1  

---

## ENTREGA 01: Documentação de Software

### 1.1 Tabela de Requisitos Funcionais do Sistema

| ID | Requisito | Descrição |
|:---|:---|:---|
| **RF01** | Autenticação e Sessão | O sistema deve permitir a autenticação de usuários cadastrados com validação de credenciais, mensagem de erro apropriada para falhas e encerramento automático da sessão após tempo de expiração (30 minutos). |
| **RF02** | Proteção de Dados (LGPD) | O sistema deve armazenar dados sensíveis dos clientes (como CPF) exclusivamente em formato hash criptográfico no banco de dados, impedindo o armazenamento em texto puro. |
| **RF03** | Painel Principal | A tela principal deve exibir obrigatoriamente o nome do usuário autenticado, links de navegação para os módulos do sistema e a opção de logout seguro. |
| **RF04** | Gestão de Clientes com Busca | O sistema deve permitir o cadastro, edição e listagem de clientes. A tela de listagem deve contar com recurso de busca por termo (nome, e-mail, telefone ou CPF completo) atualizando a visualização dinamicamente. |
| **RF05** | Vínculo e Unicidade do Recurso Secundário | Todo item secundário (ex.: Veículo, Aparelho, Pet, Aluno) deve ser associado obrigatoriamente a um cliente pré-existente e possuir um identificador único (placa, IMEI, chip, matrícula), impedindo duplicidades. |
| **RF06** | Gestão de Agendamentos Ordenada | O sistema deve listar os agendamentos **obrigatoriamente em ordem cronológica crescente de data**, exibindo detalhadamente os dados do cliente, do recurso associado e do serviço solicitado. |
| **RF07** | Reagendamento / Atualização | O sistema deve permitir alterar a data/hora e o status de um agendamento já registrado, persistindo a alteração no banco de dados e refletindo na reordenação da listagem. |
| **RF08** | Integridade Referencial | O sistema não deve permitir a exclusão de clientes ou itens que possuam vínculos ativos em agendamentos ou tabelas dependentes sem prévia remoção das dependências. |

---

### 1.2 Requisitos de Infraestrutura

- **SGBD Utilizado:** MySQL  
- **Versão:** 8.0 ou superior  
- **Linguagem de Programação:** Python  
- **Versão:** 3.10 ou superior  
- **Framework Web:** Flask 3.x  
- **Bibliotecas Principais:**  
  - `mysql-connector-python` (Comunicação com o banco)  
  - `bcrypt` (Criptografia de senhas e hashing de CPF)  

---

### 1.3 Estrutura do Banco de Dados e Diagrama Lógico

```mermaid
erDiagram
    USUARIOS {
        int id PK
        varchar nome
        varchar login UK
        char senha_hash
        timestamp criado_em
    }
    CLIENTES {
        int id PK
        varchar nome
        char cpf_hash
        varchar telefone
        varchar email
        varchar endereco
        timestamp criado_em
    }
    RECURSO_SECUNDARIO {
        int id PK
        int cliente_id FK
        varchar identificador_unico UK
        varchar detalhe_1
        varchar detalhe_2
    }
    SERVICOS {
        int id PK
        varchar descricao
        decimal valor
    }
    AGENDAMENTOS {
        int id PK
        int recurso_id FK
        int servico_id FK
        datetime data_agendamento
        enum status
        varchar observacao
    }

    CLIENTES ||--o{ RECURSO_SECUNDARIO : "possui"
    RECURSO_SECUNDARIO ||--o{ AGENDAMENTOS : "recebe"
    SERVICOS ||--o{ AGENDAMENTOS : "compoe"
```
