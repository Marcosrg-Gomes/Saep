# GUIA DEFINITIVO - PROVA PRÁTICA SAEP SENAI

Este documento contém o checklist, as regras essenciais, a matriz de correção e as respostas prontas para gabaritar a prova do SAEP SENAI (Desenvolvimento de Sistemas).

---

## 1. O Que o SAEP Cobra e Pontua (Critérios Oficiais)

Na prova prática de Desenvolvimento de Sistemas do SAEP, a entrega costuma ser dividida em **8 etapas/entregas**:

| Nº | Entrega | Arquivo Esperado | Pontos Críticos Avaliados |
|:---|:---|:---|:---|
| 1 | **Documentação de Software (Anexo 1)** | `documentacao.pdf` (ou docx) | Requisitos Funcionais (RFs) bem definidos e infraestrutura (SGBD e Linguagem com versões). |
| 2 | **Diagrama Entidade-Relacionamento (DER)** | `der.png` ou `der.pdf` | Tabelas, PKs, FKs, cardinalidade e tipos de dados corretos. |
| 3 | **Script de Banco de Dados** | `sistema_db.sql` | Criação do banco, tabelas com FKs, e **mínimo 3 registros inseridos por tabela**. |
| 4 | **Autenticação / Login** | Código em `sistema/` | Login com validação em caso de falha e controle de **tempo de expiração da sessão**. |
| 5 | **Tela Principal (Dashboard / Home)** | Código em `sistema/` | Exibição clara do **nome do usuário logado**, navegação para os módulos e **botão Sair**. |
| 6 | **Gerenciamento de Clientes** | Código em `sistema/` | **CPF com hash criptografado (LGPD)**, busca por termo que atualiza a lista e edição com persistência. |
| 7 | **Gerenciamento do Recurso Intermediário** | Código em `sistema/` | Vínculo obrigatório a um cliente existente (FK) e identificador único (Placa, IMEI, Chip, etc.). |
| 8 | **Gerenciamento de Agendamentos / Serviços** | Código em `sistema/` | **Ordenação obrigatória por data**, exibição de dados do cliente + item intermediário + serviço, e **reagendamento/atualização de data**. |

---

## 2. Erros Mais Comuns nos Modelos Antigos e Como Evitar

1. **CPF em texto puro ou criptografia reversível fraca**:
   - *Erro*: Salvar o CPF diretamente em `VARCHAR(11)` sem hashing.
   - *Correção*: Salvar na coluna `cpf_hash CHAR(60)` gerada via `bcrypt` com salt.
   - *Atenção na busca*: Hash com salt gera saídas diferentes a cada execução. Para buscar por CPF, faz-se o loop comparando com `bcrypt.checkpw(cpf.encode(), hash_salvo.encode())`.

2. **Senha em texto puro no SQL inicial**:
   - *Erro*: Inserir senhas como `'admin123'` no script `.sql`.
   - *Correção*: Sempre inserir o hash bcrypt de 60 caracteres no script `INSERT INTO usuarios ...`.

3. **Falta do mínimo de 3 registros em todas as tabelas**:
   - *Erro*: Deixar tabelas vazias ou com apenas 1 ou 2 registros de exemplo. O descumprimento perde nota inteira da Entrega 3.
   - *Correção*: Cada tabela (`usuarios`, `clientes`, `recurso_secundario`, `servicos`, `agendamentos`) **deve ter rigorosamente 3 ou mais `INSERT`s**.

4. **Agendamentos sem ordenação por data**:
   - *Erro*: `SELECT ... ORDER BY id` ou sem `ORDER BY`.
   - *Correção*: Obrigatoriamente `ORDER BY a.data_agendamento ASC`.

5. **Sessão sem tempo de expiração**:
   - *Erro*: Deixar a sessão do Flask ativa indefinidamente.
   - *Correção*: Guardar `session['login_em'] = time.time()` e verificar `time.time() - session['login_em'] <= EXPIRACAO_SEGUNDOS` em toda requisição protegida (`@before_request`).

6. **Não exibir o nome do usuário logado na tela principal**:
   - *Erro*: Colocar apenas um menu estático.
   - *Correção*: Chamar `/api/me` ou injetar o nome da sessão no cabeçalho: `Usuário: Administrador | Sair`.

---

## 3. Arquitetura Padrão (Clean & Rápida para a Prova)

```
SeuNomeCompleto.zip
├── documentacao.pdf (ou .docx preenchido)
├── der.png (ou der.pdf)
├── sistema_db.sql
└── sistema/
    ├── app.py                  # Ponto de entrada do Flask e inicialização
    ├── db.py                   # Conexão MySQL com tratamento de erros
    ├── autenticacao.py         # Criptografia bcrypt e controle de expiração de sessão
    ├── clientes.py             # Regras de negócio e CRUD de clientes (com busca)
    ├── recurso_secundario.py   # Aparelhos / Veículos / Pets / etc.
    ├── agendamento.py          # Agendamentos ordenados por data
    ├── rotas.py                # Rotas da API e renderização de páginas
    ├── requirements.txt        # Flask, bcrypt, mysql-connector-python
    ├── static/
    │   ├── style.css           # Estilos limpos e responsivos
    │   └── app.js              # Fetch API e manipulação dinâmica de tela
    └── templates/
        ├── login.html
        ├── principal.html
        ├── clientes.html
        ├── recurso_secundario.html
        └── agendamentos.html
```
