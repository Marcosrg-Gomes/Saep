# INSTRUÇÕES RÁPIDAS - SISTEMA OFICIAL DA PROVA PRÁTICA (PET SHOP)

Este projeto foi construído exatamente com as regras exigidas na sua prova do SAEP:
1. **Validação de Login com mensagem de erro clara em caso de falha**.
2. **Relacionamento de 1 dono para vários pets, e cada pet com apenas 1 dono**.
3. **Dropdown obrigatório no cadastro de pet para escolher o tutor**.
4. **Campo de pesquisa em tempo real na parte de tutores**.
5. **Cabeçalho com botão de Logout ("Sair") e nome da conta logada visível**.
6. **3 páginas completas de trabalho:**
   - `http://localhost:5000/tutores`
   - `http://localhost:5000/pets`
   - `http://localhost:5000/agendamentos`

---

## Como Executar na Hora da Prova

### 1. Criar o Banco no MySQL:
```powershell
mysql -u root -pSenai@118 < petshop_db.sql
```

### 2. Testar a Conexão:
```powershell
python testar_conexao.py
```

### 3. Iniciar o Sistema:
```powershell
python app.py
```

Abra no navegador: 👉 **`http://localhost:5000`**

### Credenciais de Teste:
- **Usuário:** `admin` | **Senha:** `admin123`
- **Usuário:** `carlos` | **Senha:** `carlos123`
- **Usuário:** `ana` | **Senha:** `ana12345`
