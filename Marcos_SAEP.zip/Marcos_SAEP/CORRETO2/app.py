import os
import sys

# Redireciona a execução diretamente para o app.py dentro da pasta sistema/
DIRETORIO_SISTEMA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sistema")
sys.path.insert(0, DIRETORIO_SISTEMA)
os.chdir(DIRETORIO_SISTEMA)

import app

if __name__ == "__main__":
    app.app.run(host="0.0.0.0", port=5000, debug=True)
