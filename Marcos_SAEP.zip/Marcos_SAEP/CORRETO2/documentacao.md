# ANEXO 1 - DOCUMENTAÇÃO DE SOFTWARE
## Sistema de Gestão para Pet Shop & Clínica Veterinária

**Estudante:** [Seu Nome Completo]  
**Data:** 06/11/2026  
**Número da Prova:** 1  

---

### ENTREGA 01: Documentação de Software

#### 1.1 Tabela de Requisitos Funcionais do Sistema

| ID | Requisito | Descrição |
|:---|:---|:---|
| **RF01** | Autenticação com Tratamento de Erro | Permitir login de usuários autorizados. Em caso de falha de autenticação (usuário inexistente ou senha incorreta), exibir mensagem clara na tela e bloquear o acesso. A sessão expira após 30 minutos de inatividade. |
| **RF02** | Proteção de Dados Pessoais (LGPD) | Armazenar o CPF dos tutores exclusivamente na forma de hash criptográfico `bcrypt` no banco de dados. |
| **RF03** | Cabeçalho e Sessão de Usuário | Exibir em todas as páginas o nome da conta conectada (`/api/me`) e um botão de logout ("Sair") que encerra a sessão e redireciona para a tela de login. |
| **RF04** | Gestão e Pesquisa de Tutores | Cadastro, edição e listagem de tutores. A tela deve conter campo de busca textual em tempo real por nome, telefone, e-mail ou correspondência de CPF. |
| **RF05** | Relacionamento 1:N (Tutor e Pets) | O sistema deve permitir que um mesmo dono possua vários pets cadastrados, mas cada pet pertence a apenas um tutor. |
| **RF06** | Dropdown de Seleção de Tutores | O formulário de cadastro de pets deve conter obrigatoriamente um campo Dropdown (`<select>`) populado dinamicamente com os tutores já existentes para vincular o dono ao animal. |
| **RF07** | Agendamentos Ordenados por Data | Listar os agendamentos **obrigatoriamente ordenados de forma crescente por data e hora**, exibindo os dados do tutor, do pet e do serviço solicitado. |
| **RF08** | Reagendamento de Atendimentos | Permitir a atualização da data/hora e do status de um agendamento já registrado, salvando no banco de dados. |

---

#### 1.2 Requisitos Não Funcionais

| ID | Categoria | Descrição |
|:---|:---|:---|
| **RNF01** | Segurança | Hash com salt dinâmico (`bcrypt`) para senhas e CPFs. |
| **RNF02** | Segurança | Expiração automática de sessão após 30 minutos a partir do login. |
| **RNF03** | Segurança | Prevenção a SQL Injection através de consultas preparadas com `%s`. |
| **RNF04** | Usabilidade | Interface dividida em 3 páginas claras (Tutores, Pets e Agendamentos) com navegação fluida. |

---

#### 1.3 Requisitos de Infraestrutura

- **SGBD Utilizado:** MySQL  
- **Versão:** 8.0 ou superior (instalado: 8.0.40)  
- **Porta:** 3306  
- **Linguagem de Programação:** Python  
- **Versão:** 3.10 ou superior (instalado: 3.13)  
- **Framework Web:** Flask 3.x  
- **Bibliotecas:** `mysql-connector-python`, `bcrypt`

---

#### 1.4 Diagrama Entidade-Relacionamento (DER)

```mermaid
erDiagram
    USUARIOS {
        int id PK
        varchar nome
        varchar login UK
        char senha_hash
        timestamp criado_em
    }

    CLIENTES {
        int id PK
        varchar nome
        char cpf_hash
        varchar telefone
        varchar email
        varchar endereco
        timestamp criado_em
    }

    PETS {
        int id PK
        int cliente_id FK
        varchar chip UK
        varchar nome
        varchar especie
        varchar raca
        varchar porte
        varchar observacao
    }

    SERVICOS {
        int id PK
        varchar descricao
        decimal valor
    }

    AGENDAMENTOS {
        int id PK
        int pet_id FK
        int servico_id FK
        datetime data_agendamento
        enum status
        varchar observacao
    }

    CLIENTES ||--o{ PETS : "possui (1 dono para varios pets)"
    PETS ||--o{ AGENDAMENTOS : "recebe"
    SERVICOS ||--o{ AGENDAMENTOS : "compoe"
```
