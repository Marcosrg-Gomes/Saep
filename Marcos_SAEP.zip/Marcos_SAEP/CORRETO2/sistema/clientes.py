"""
Módulo de Tutores (Clientes / Donos dos Pets)
- Proteção de CPF por LGPD com hash bcrypt
- Recurso de pesquisa dinâmica em tempo real (Nome, Email, Telefone ou CPF)
- Edição com persistência e integridade referencial
"""
import re
from autenticacao import conferir, gerar_hash
from db import ErroNegocio, execute, query

COLUNAS = "id, nome, telefone, email, endereco, criado_em"


def apenas_digitos(s: str) -> str:
    """Extrai apenas os números da string."""
    return re.sub(r"\D", "", s or "")


def cpf_valido(cpf: str) -> bool:
    """Confere se o CPF informado possui 11 dígitos."""
    return len(apenas_digitos(cpf)) == 11


def _validar(dados: dict, cpf_obrigatorio: bool = True):
    """Valida os dados informados para o tutor."""
    nome = (dados.get("nome") or "").strip()
    email = (dados.get("email") or "").strip()
    cpf = apenas_digitos(dados.get("cpf"))

    if len(nome) < 3:
        raise ErroNegocio("Informe o nome completo do tutor (mínimo 3 caracteres).")

    if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ErroNegocio("E-mail em formato inválido.")

    if cpf_obrigatorio or cpf:
        if not cpf_valido(cpf):
            raise ErroNegocio("CPF inválido: informe os 11 dígitos numéricos.")

    return nome, cpf, email


def _cpf_ja_cadastrado(cpf: str, ignorar_id: int = 0) -> bool:
    """Confere se o CPF já existe comparando o hash bcrypt."""
    registros = query("SELECT id, cpf_hash FROM clientes")
    for r in registros:
        if r["id"] != ignorar_id and conferir(cpf, r["cpf_hash"]):
            return True
    return False


def listar(termo: str = ""):
    """
    Lista tutores. Se houver pesquisa (?q=termo),
    filtra por nome, email, telefone ou busca direta por CPF via hash.
    """
    termo = (termo or "").strip()
    if not termo:
        return query(f"SELECT {COLUNAS} FROM clientes ORDER BY nome ASC")

    filtro = f"%{termo}%"
    resultados = query(
        f"SELECT {COLUNAS} FROM clientes WHERE nome LIKE %s OR email LIKE %s OR telefone LIKE %s ORDER BY nome ASC",
        (filtro, filtro, filtro)
    )

    # Pesquisa por CPF completo
    cpf_busca = apenas_digitos(termo)
    if len(cpf_busca) == 11:
        ids_encontrados = {item["id"] for item in resultados}
        todos = query("SELECT id, cpf_hash FROM clientes")
        for c in todos:
            if c["id"] not in ids_encontrados and conferir(cpf_busca, c["cpf_hash"]):
                cliente_cpf = query(f"SELECT {COLUNAS} FROM clientes WHERE id = %s", (c["id"],))
                resultados.extend(cliente_cpf)

    return resultados


def obter(id_: int) -> dict:
    """Retorna dados de um único tutor pelo ID."""
    tutores = query(f"SELECT {COLUNAS} FROM clientes WHERE id = %s", (id_,))
    if not tutores:
        raise ErroNegocio("Tutor não encontrado.", 404)
    return tutores[0]


def cadastrar(dados: dict) -> dict:
    """Cadastra novo tutor com CPF gravado exclusivamente como hash bcrypt."""
    nome, cpf, email = _validar(dados, cpf_obrigatorio=True)
    if _cpf_ja_cadastrado(cpf):
        raise ErroNegocio("Já existe um tutor cadastrado com este CPF.", 409)

    novo_id = execute(
        "INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES (%s, %s, %s, %s, %s)",
        (nome, gerar_hash(cpf), dados.get("telefone"), email or None, dados.get("endereco"))
    )
    return obter(novo_id)


def editar(id_: int, dados: dict) -> dict:
    """Atualiza os dados de um tutor existente."""
    obter(id_)
    nome, cpf, email = _validar(dados, cpf_obrigatorio=False)

    if cpf and _cpf_ja_cadastrado(cpf, ignorar_id=id_):
        raise ErroNegocio("Já existe outro tutor cadastrado com este CPF.", 409)

    execute(
        "UPDATE clientes SET nome = %s, telefone = %s, email = %s, endereco = %s WHERE id = %s",
        (nome, dados.get("telefone"), email or None, dados.get("endereco"), id_)
    )

    if cpf:
        execute("UPDATE clientes SET cpf_hash = %s WHERE id = %s", (gerar_hash(cpf), id_))

    return obter(id_)


def excluir(id_: int):
    """Exclui o tutor se não houver pets vinculados a ele."""
    obter(id_)
    if query("SELECT id FROM pets WHERE cliente_id = %s LIMIT 1", (id_,)):
        raise ErroNegocio("O tutor possui pets vinculados. Exclua os pets antes de remover o tutor.", 409)
    execute("DELETE FROM clientes WHERE id = %s", (id_,))
