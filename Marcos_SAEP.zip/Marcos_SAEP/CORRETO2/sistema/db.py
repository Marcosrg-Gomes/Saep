"""
Módulo de Acesso ao MySQL com Parâmetros Seguros (%s)
"""
import os
from datetime import date, datetime
import mysql.connector

CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "Senai@118"),
    "database": os.getenv("DB_NAME", "petshop_db"),
}


class ErroNegocio(Exception):
    """Exceção para validações e mensagens de negócio em JSON."""
    def __init__(self, mensagem, status=400):
        super().__init__(mensagem)
        self.mensagem = mensagem
        self.status = status


def query(sql, params=()):
    """Executa SELECT e devolve lista de dicionários com datas formatadas."""
    with mysql.connector.connect(**CONFIG) as con, con.cursor(dictionary=True) as cur:
        cur.execute(sql, params)
        return [
            {
                k: v.isoformat() if isinstance(v, (date, datetime)) else v
                for k, v in row.items()
            }
            for row in cur.fetchall()
        ]


def execute(sql, params=()):
    """Executa INSERT/UPDATE/DELETE com commit garantido e retorna lastrowid."""
    with mysql.connector.connect(**CONFIG) as con, con.cursor() as cur:
        cur.execute(sql, params)
        con.commit()
        return cur.lastrowid


def buscar_um(sql, params, mensagem="Registro não encontrado."):
    """Busca um único registro ou dispara HTTP 404."""
    linhas = query(sql, params)
    if not linhas:
        raise ErroNegocio(mensagem, 404)
    return linhas[0]


def bloquear_se_existir(sql, params, mensagem="Registro já existente."):
    """Bloqueia duplicidades com HTTP 409."""
    if query(sql, params):
        raise ErroNegocio(mensagem, 409)


def testar_conexao():
    """Valida a conexão com o banco MySQL."""
    return query("SELECT DATABASE() AS banco, VERSION() AS versao")[0]
