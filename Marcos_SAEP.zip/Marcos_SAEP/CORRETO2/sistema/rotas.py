"""
Mapeamento de Rotas HTTP, Páginas e API REST
"""
import mysql.connector
from flask import Blueprint, abort, jsonify, redirect, request, send_from_directory, session
import agendamento, autenticacao as auth, clientes, pets
from db import ErroNegocio, testar_conexao

bp = Blueprint("rotas", __name__)

ROTAS_LIVRES = ("/", "/login", "/api/login", "/api/logout", "/api/teste-conexao")
PAGINAS = ("login", "tutores", "pets", "agendamentos")
MODULOS = {
    "tutores": clientes,
    "clientes": clientes,
    "pets": pets,
    "agendamentos": agendamento
}


@bp.before_request
def verificar_autenticacao():
    """Verifica login e expiração de sessão antes de qualquer rota restrita."""
    if request.path in ROTAS_LIVRES or auth.logado():
        return None

    if request.path.startswith("/api/"):
        return jsonify(erro="Sessão expirada. Faça login novamente."), 401

    return redirect("/login?expirou=1")


@bp.app_errorhandler(ErroNegocio)
def tratar_erro_negocio(erro):
    return jsonify(erro=erro.mensagem), erro.status


@bp.app_errorhandler(mysql.connector.Error)
def tratar_erro_banco(erro):
    return jsonify(erro="Erro de comunicação com o banco de dados."), 500


def corpo_json():
    return request.get_json(silent=True) or {}


# =============================================================================
# PÁGINAS HTML (3 PÁGINAS PRINCIPAIS + LOGIN)
# =============================================================================

@bp.route("/")
def raiz():
    return redirect("/tutores" if auth.logado() else "/login")


@bp.route("/<pagina>")
def renderizar_pagina(pagina):
    if pagina not in PAGINAS:
        abort(404)
    return send_from_directory("templates", f"{pagina}.html")


# =============================================================================
# ROTAS DA API
# =============================================================================

@bp.post("/api/login")
def login():
    dados = corpo_json()
    usuario = auth.autenticar(dados.get("login"), dados.get("senha"))
    auth.iniciar_sessao(usuario)
    return jsonify(ok=True, nome=session["nome"])


@bp.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@bp.get("/api/me")
def me():
    """Retorna o nome da conta logada para exibir no cabeçalho."""
    return jsonify(nome=session["nome"])


@bp.get("/api/teste-conexao")
def teste():
    return jsonify(testar_conexao())


@bp.get("/api/servicos")
def servicos():
    return jsonify(agendamento.listar_servicos())


# CRUD Genérico
def obter_modulo(recurso: str):
    mod = MODULOS.get(recurso)
    if not mod:
        raise ErroNegocio("Recurso não encontrado.", 404)
    return mod


@bp.route("/api/<recurso>", methods=["GET", "POST"])
def colecao(recurso):
    mod = obter_modulo(recurso)
    if request.method == "POST":
        return jsonify(mod.cadastrar(corpo_json())), 201

    # Pesquisa de tutores com query param ?q=
    if "q" in request.args and hasattr(mod, "listar"):
        return jsonify(mod.listar(request.args.get("q")))

    return jsonify(mod.listar())


@bp.route("/api/<recurso>/<int:id_>", methods=["GET", "PUT", "DELETE"])
def elemento(recurso, id_):
    mod = obter_modulo(recurso)
    if request.method == "GET":
        return jsonify(mod.obter(id_))
    elif request.method == "PUT":
        return jsonify(mod.editar(id_, corpo_json()))
    elif request.method == "DELETE":
        mod.excluir(id_)
        return jsonify(ok=True)
