"""
Módulo de Pets (Animais de Estimação)
Regras de Negócio:
1. Vários pets podem pertencer ao mesmo dono (cliente_id).
2. Cada pet pertence a APENAS 1 dono (chave estrangeira cliente_id obrigatória).
3. Seleção do tutor via Dropdown.
4. Microchip (chip) único por animal.
"""
from db import ErroNegocio, bloquear_se_existir, buscar_um, execute, query

SELECT = """
    SELECT
        p.id,
        p.cliente_id,
        c.nome AS cliente_nome,
        c.telefone AS cliente_telefone,
        p.chip,
        p.nome,
        p.especie,
        p.raca,
        p.porte,
        p.observacao
    FROM pets p
    JOIN clientes c ON c.id = p.cliente_id
"""


def _inteiro(valor, mensagem):
    try:
        return int(valor)
    except (TypeError, ValueError):
        raise ErroNegocio(mensagem)


def _validar(dados: dict, id_: int = 0):
    """Valida campos do pet e confere se o tutor existe."""
    chip = (dados.get("chip") or "").strip()
    nome = (dados.get("nome") or "").strip()
    especie = (dados.get("especie") or "").strip()
    raca = (dados.get("raca") or "").strip()
    porte = (dados.get("porte") or "").strip()
    observacao = (dados.get("observacao") or "").strip()

    if not chip:
        raise ErroNegocio("Informe o código do microchip ou identificador do pet.")
    if not nome:
        raise ErroNegocio("Informe o nome do pet.")
    if not especie:
        raise ErroNegocio("Informe a espécie (ex.: Canino, Felino).")
    if not raca:
        raise ErroNegocio("Informe a raça.")

    # Dropdown de seleção do Tutor
    cliente_id = _inteiro(dados.get("cliente_id"), "Selecione o tutor (dono) do pet no dropdown.")
    buscar_um("SELECT id FROM clientes WHERE id = %s", (cliente_id,), "O tutor selecionado não está cadastrado.")

    # Unicidade do Chip
    bloquear_se_existir(
        "SELECT id FROM pets WHERE chip = %s AND id <> %s",
        (chip, id_),
        "Já existe outro animal cadastrado com este microchip."
    )

    return cliente_id, chip, nome, especie, raca, porte, observacao


def listar():
    """Lista todos os pets cadastrados ordenados pelo nome do tutor e nome do pet."""
    return query(SELECT + " ORDER BY c.nome ASC, p.nome ASC")


def obter(id_: int) -> dict:
    """Busca os dados de um pet específico."""
    return buscar_um(SELECT + " WHERE p.id = %s", (id_,), "Pet não encontrado.")


def cadastrar(dados: dict) -> dict:
    """Cadastra um novo pet associando-o obrigatoriamente a um tutor."""
    params = _validar(dados)
    novo_id = execute(
        "INSERT INTO pets (cliente_id, chip, nome, especie, raca, porte, observacao) VALUES (%s, %s, %s, %s, %s, %s, %s)",
        params
    )
    return obter(novo_id)


def editar(id_: int, dados: dict) -> dict:
    """Atualiza dados do pet."""
    obter(id_)
    params = _validar(dados, id_)
    execute(
        "UPDATE pets SET cliente_id=%s, chip=%s, nome=%s, especie=%s, raca=%s, porte=%s, observacao=%s WHERE id=%s",
        (*params, id_)
    )
    return obter(id_)


def excluir(id_: int):
    """Exclui o pet se não possuir agendamentos ativos."""
    obter(id_)
    bloquear_se_existir(
        "SELECT id FROM agendamentos WHERE pet_id = %s",
        (id_,),
        "O pet possui agendamentos marcados. Exclua os agendamentos antes de remover o pet."
    )
    execute("DELETE FROM pets WHERE id = %s", (id_,))
