"""
Módulo de Autenticação e Sessão
- Validação de Login com mensagem de erro clara em caso de falha
- Hash Bcrypt seguro
- Expiração de sessão em 30 minutos
"""
import time
import bcrypt
from flask import session
from db import ErroNegocio, query

EXPIRACAO_SEGUNDOS = 30 * 60  # 30 minutos


def gerar_hash(texto: str) -> str:
    """Gera hash bcrypt com salt dinâmico."""
    return bcrypt.hashpw(texto.encode("utf-8"), bcrypt.gensalt(10)).decode("utf-8")


def conferir(texto: str, hash_salvo: str) -> bool:
    """Confere texto puro contra o hash bcrypt salvo."""
    try:
        return bcrypt.checkpw(texto.encode("utf-8"), hash_salvo.encode("utf-8"))
    except Exception:
        return False


def autenticar(login: str, senha: str) -> dict:
    """
    Valida credenciais do usuário.
    Se falhar, emite mensagem de erro sem vazar se o usuário existe.
    """
    login = (login or "").strip()
    senha = senha or ""

    if not login or not senha:
        raise ErroNegocio("Informe usuário e senha para acessar.")

    usuarios = query("SELECT id, nome, login, senha_hash FROM usuarios WHERE login = %s", (login,))
    if not usuarios or not conferir(senha, usuarios[0]["senha_hash"]):
        raise ErroNegocio("Usuário ou senha inválidos.", 401)

    return usuarios[0]


def iniciar_sessao(usuario: dict):
    """Salva os dados do usuário autenticado na sessão."""
    session.clear()
    session.permanent = True
    session["usuario_id"] = usuario["id"]
    session["nome"] = usuario["nome"]
    session["login_em"] = time.time()


def logado() -> bool:
    """Verifica se há sessão ativa e dentro do limite de 30 minutos."""
    if "usuario_id" in session:
        if time.time() - session.get("login_em", 0) <= EXPIRACAO_SEGUNDOS:
            return True
    session.clear()
    return False
