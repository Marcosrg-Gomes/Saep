-- ====================================================================
-- Script: lavarapido_db.sql | MySQL 8+
-- Tema: Centro de Estética Automotiva & Lava Rápido
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS lavarapido_db;
CREATE DATABASE lavarapido_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lavarapido_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Veículos do Cliente (Placa Única)
CREATE TABLE IF NOT EXISTS veiculos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  placa VARCHAR(10) NOT NULL UNIQUE,
  modelo VARCHAR(60) NOT NULL,
  cor VARCHAR(30) NOT NULL,
  categoria VARCHAR(30) NOT NULL,            -- Hatch, Sedan, SUV, Picape
  CONSTRAINT fk_lav_veic_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  veiculo_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_lav_veic FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
  CONSTRAINT fk_ag_lav_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

-- Inserção de 3 registros por tabela
INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Gerente Roberto', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Paulo Detalhador', 'paulo', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Juliana Caixa', 'juliana', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Gustavo Silveira', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-7711', 'gustavo@email.com', 'Rua dos Motores, 45'),
('Patricia Prado', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-8822', 'patricia@email.com', 'Av. Automotiva, 700'),
('Ricardo Faria', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-9933', 'ricardo@email.com', 'Rua das Rodas, 12');

INSERT INTO veiculos (cliente_id, placa, modelo, cor, categoria) VALUES
(1, 'BRA2E19', 'Honda Civic Touring', 'Cinza Metálico', 'Sedan'),
(2, 'SEN4I26', 'Jeep Compass Longitude', 'Branco Polar', 'SUV'),
(3, 'ABC1234', 'Volkswagen Golf GTI', 'Vermelho', 'Hatch');

INSERT INTO servicos (descricao, valor) VALUES
('Lavagem Técnica Detalhada com Cera', 80.00),
('Higienização Interna e Oxi-Sanitização', 190.00),
('Polimento Comercial e Proteção de Pintura', 350.00);

INSERT INTO agendamentos (veiculo_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 13:00:00', 'AGENDADO', 'Cliente aguardará na sala de espera'),
(2, 2, '2026-11-07 08:30:00', 'AGENDADO', 'Bancos claros com manchas de café'),
(3, 3, '2026-11-08 10:00:00', 'AGENDADO', 'Remover marcas de lavagem anteriores');
