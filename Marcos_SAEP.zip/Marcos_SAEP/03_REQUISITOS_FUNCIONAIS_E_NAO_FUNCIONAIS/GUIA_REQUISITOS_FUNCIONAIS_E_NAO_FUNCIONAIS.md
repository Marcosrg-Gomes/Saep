# GUIA COMPLETO DE REQUISITOS (FUNCIONAIS E NÃO FUNCIONAIS) - SAEP SENAI

Este documento é a sua referência definitiva para preencher a **Entrega 01 (Documentação de Software / Anexo 1)** e tirar nota máxima.

---

## 1. O QUE SÃO E A DIFERENÇA EXIGIDA NA AVALIAÇÃO DO SENAI

- **Requisitos Funcionais (RF):** Descrevem **o que o sistema deve fazer** (funcionalidades, ações do usuário, regras de negócio, telas e cálculos).
- **Requisitos Não Funcionais (RNF):** Descrevem **como o sistema deve operar** em termos de restrições de qualidade, segurança, desempenho, usabilidade, infraestrutura e conformidade legal (ex.: LGPD).

---

## 2. TABELA PADRÃO DE REQUISITOS FUNCIONAIS (RF01 A RF10)

Copie e utilize esta tabela na sua documentação (`documentacao.pdf` ou `.docx`):

| ID | Requisito Funcional | Descrição Detalhada | Critério de Aceite / Teste |
|:---|:---|:---|:---|
| **RF01** | Autenticação de Usuários | O sistema deve disponibilizar tela de login para que usuários autorizados acessem as funcionalidades restritas. Em caso de credenciais inválidas ou campos vazios, deve emitir mensagem de aviso clara sem divulgar detalhes de banco. | Digitar usuário ou senha errados deve retornar status HTTP 401 e exibir *"Usuário ou senha inválidos."*. |
| **RF02** | Proteção e Criptografia de Dados Pessoais | O sistema deve capturar o CPF do cliente e convertê-lo em um hash criptográfico irreversível antes de gravar no banco de dados, em conformidade com a LGPD. | Consulta direta ao banco de dados (`SELECT cpf_hash FROM clientes`) deve exibir string de 60 caracteres iniciada por `$2b$10$`. |
| **RF03** | Painel Principal (Dashboard) | A página principal (`/principal`) deve exibir de forma visível o nome do usuário autenticado na sessão, atalhos de navegação para os módulos do sistema e botão para logout seguro. | Ao acessar logado, a interface deve carregar `"Usuário: <Nome>"` via `/api/me`. O botão "Sair" encerra a sessão. |
| **RF04** | Cadastro e Edição de Clientes | O sistema deve permitir o cadastro de novos clientes com validação de dados obrigatórios e permitir a alteração posterior das informações já cadastradas com persistência no banco. | Edição de telefone/endereço deve salvar no banco e refletir imediatamente na listagem. |
| **RF05** | Busca Dinâmica de Clientes | A listagem de clientes deve conter campo de busca textual. Ao submeter o termo, a tabela deve atualizar exibindo correspondências por nome, telefone, e-mail ou correspondência exata de CPF via comparação de hash. | Digitar parte do nome filtra via `LIKE`; digitar os 11 dígitos do CPF localiza o cliente correto. |
| **RF06** | Gestão do Recurso Intermediário com Vínculo | O cadastro do item secundário (Aparelho, Veículo, Pet, Prontuário, Quarto, Mesa) deve exigir a seleção obrigatória de um cliente previamente cadastrado (Chave Estrangeira). | Não deve ser possível cadastrar o item sem associar um cliente existente. |
| **RF07** | Unicidade do Identificador do Recurso | O sistema deve validar e impedir o cadastro de itens com identificadores duplicados (Placa, IMEI, Microchip, Carteirinha, ISBN). | Tentar cadastrar duplicado deve retornar status HTTP 409 (*"Identificador já cadastrado."*). |
| **RF08** | Agendamento Ordenado Cronologicamente | A listagem de agendamentos/serviços deve ser exibida obrigatoriamente em **ordem cronológica crescente por data e hora**, exibindo dados do cliente, do recurso associado e do serviço. | A consulta SQL deve conter `ORDER BY data_agendamento ASC`. Serviços mais próximos aparecem no topo. |
| **RF09** | Reagendamento de Atendimentos | O sistema deve permitir a alteração da data/hora e do status de um agendamento já realizado, atualizando a listagem e sua ordem cronológica em tempo real. | Ao mudar a data de um atendimento, ele é reposicionado na tabela conforme a nova data. |
| **RF10** | Integridade Referencial na Exclusão | O sistema deve bloquear a exclusão de clientes que possuam recursos vinculados e de recursos que possuam agendamentos ativos. | Tentativa de exclusão com dependências retorna erro 409 (*"Possui agendamentos ativos. Exclua-os antes."*). |

---

## 3. TABELA PADRÃO DE REQUISITOS NÃO FUNCIONAIS (RNF01 A RNF08)

| ID | Categoria | Requisito Não Funcional | Descrição / Métrica |
|:---|:---|:---|:---|
| **RNF01** | Segurança | Expiração de Sessão por Inatividade | A sessão do usuário deve expirar automaticamente após 30 minutos a partir do momento do login. Qualquer requisição posterior deve ser bloqueada e redirecionada à tela de autenticação. |
| **RNF02** | Segurança | Criptografia Forte (LGPD) | Senhas de usuários e CPFs de clientes devem ser protegidos com o algoritmo `bcrypt` com salt dinâmico e custo mínimo de 10 rounds, garantindo proteção contra ataques de força bruta e tabelas rainbow. |
| **RNF03** | Segurança | Prevenção a SQL Injection | Todas as interações com o SGBD devem utilizar consultas parametrizadas (*Prepared Statements* com marcadores `%s`), sem concatenação direta de strings. |
| **RNF04** | Desempenho | Tempo de Resposta da API | As consultas de listagem e operações de cadastro/edição devem responder com tempo inferior a 500 milissegundos em ambiente local. |
| **RNF05** | Usabilidade | Interface Responsiva e Sanitizada | A interface web deve ser limpa, responsiva para telas desktop padrão e utilizar inserção segura no DOM (`textContent`) para prevenção de vulnerabilidades XSS (*Cross-Site Scripting*). |
| **RNF06** | Arquitetura | Separação em Camadas (REST / MVC) | O backend deve adotar arquitetura modular separando a persistência (`db.py`), as regras de negócio (`clientes.py`, `recurso.py`, `agendamento.py`), a segurança (`autenticacao.py`) e a camada de rotas/API (`rotas.py`). |
| **RNF07** | Infraestrutura | Compatibilidade de Plataforma | A solução deve operar sobre ambiente multiplataforma (Windows e Linux) com suporte nativo a Python 3.10+ e SGBD MySQL 8.0+. |
| **RNF08** | Confiabilidade | Tratamento Centralizado de Erros | Erros de banco de dados ou regras violadas não devem expor rastros de pilha (*stack trace*) ao cliente final, retornando respostas padronizadas em formato JSON com código de status HTTP condizente (400, 401, 404, 409, 500). |

---

## 4. DADOS DE INFRAESTRUTURA PARA PREENCHER NO ANEXO 1

- **SGBD Utilizado:** MySQL
- **Versão do SGBD:** 8.0 ou superior (versão instalada no laboratório: `8.0.40`)
- **Porta Padrão:** 3306
- **Linguagem de Programação:** Python
- **Versão da Linguagem:** 3.10 ou superior (versão instalada: `3.13.x`)
- **Framework Web:** Flask (versão `3.0.3`)
- **Bibliotecas Auxiliares:**
  - `mysql-connector-python` (versão 9.0+)
  - `bcrypt` (versão 4.2+)
