-- ====================================================================
-- Script: locadora_db.sql | MySQL 8+
-- Tema: Locadora de Veículos & Rent a Car
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS locadora_db;
CREATE DATABASE locadora_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE locadora_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recurso Secundário: Contratos de Locação / Vínculo com a CNH do Cliente
CREATE TABLE IF NOT EXISTS contratos_locacao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  numero_cnh VARCHAR(20) NOT NULL UNIQUE,      -- Identificador Único do Condutor
  categoria_cnh VARCHAR(5) NOT NULL,           -- B, AB, C, D
  validade_cnh DATE NOT NULL,
  categoria_veiculo VARCHAR(30) NOT NULL,      -- Econômico, Sedã Executivo, SUV
  CONSTRAINT fk_locacao_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contrato_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_contrato FOREIGN KEY (contrato_id) REFERENCES contratos_locacao(id),
  CONSTRAINT fk_ag_loc_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Supervisor de Frota', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Marcos Atendente', 'marcos', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Renata Contratos', 'renata', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Claudio Roberto', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-9988', 'claudio@email.com', 'Av. das Nações Unidas, 1000'),
('Sabrina Sato', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-8877', 'sabrina@email.com', 'Rua Pamplona, 500'),
('Leonardo DiCaprio', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-7766', 'leonardo@email.com', 'Alameda Santos, 220');

INSERT INTO contratos_locacao (cliente_id, numero_cnh, categoria_cnh, validade_cnh, categoria_veiculo) VALUES
(1, '04598712390', 'B', '2028-10-15', 'Sedã Automático'),
(2, '07812398411', 'AB', '2027-05-20', 'SUV Compacto'),
(3, '09934581233', 'B', '2029-01-10', 'Econômico 1.0 com Ar');

INSERT INTO servicos (descricao, valor) VALUES
('Diária Locação com Quilometragem Livre', 140.00),
('Proteção e Seguro Total do Casco (CDW)', 45.00),
('Adicional de Condutor Jovem / GPS', 30.00);

INSERT INTO agendamentos (contrato_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 11:30:00', 'AGENDADO', 'Retirada no aeroporto de Congonhas'),
(2, 2, '2026-11-07 14:00:00', 'AGENDADO', 'Solicitou cadeirinha de bebê instalada'),
(3, 3, '2026-11-08 09:00:00', 'AGENDADO', 'Tanque cheio na entrega');
