import os
import sys

DIRETORIO_ATUAL = os.path.dirname(os.path.abspath(__file__))
if DIRETORIO_ATUAL not in sys.path:
    sys.path.insert(0, DIRETORIO_ATUAL)

from flask import Flask
from rotas import bp

# Configura caminhos absolutos para static e templates funcionarem de qualquer diretório
STATIC_DIR = os.path.join(DIRETORIO_ATUAL, "static")
TEMPLATES_DIR = os.path.join(DIRETORIO_ATUAL, "templates")

app = Flask(__name__, static_folder=STATIC_DIR, template_folder=TEMPLATES_DIR)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "chave-secreta-saep-senai-2026")

app.register_blueprint(bp)

if __name__ == "__main__":
    print("==================================================")
    print("  SISTEMA PET SHOP & CLÍNICA INICIADO!")
    print("  Abra no seu navegador: http://localhost:5000")
    print("  Usuário: admin | Senha: admin123")
    print("==================================================")
    app.run(host="0.0.0.0", port=5000, debug=True)
