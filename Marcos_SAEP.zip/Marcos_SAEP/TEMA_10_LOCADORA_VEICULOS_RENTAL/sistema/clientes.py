"""
Regras de Negócio e Operações para Clientes (Tutores)
O CPF é armazenado exclusivamente como hash bcrypt para conformidade com a LGPD.
"""
import re
from autenticacao import conferir, gerar_hash
from db import ErroNegocio, execute, query

COLUNAS = "id, nome, telefone, email, endereco, criado_em"


def apenas_digitos(valor: str) -> str:
    """Extrai somente caracteres numéricos de uma string."""
    return re.sub(r"\D", "", valor or "")


def cpf_valido(cpf: str) -> bool:
    """Validação de CPF com verificação de 11 dígitos."""
    digitos = apenas_digitos(cpf)
    return len(digitos) == 11


def _validar_dados(dados: dict, cpf_obrigatorio: bool = True):
    """Aplica as regras de validação nos campos informados."""
    nome = (dados.get("nome") or "").strip()
    email = (dados.get("email") or "").strip()
    cpf = apenas_digitos(dados.get("cpf"))

    if len(nome) < 3:
        raise ErroNegocio("Informe o nome completo (mínimo 3 letras).")

    if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ErroNegocio("E-mail com formato inválido.")

    if cpf_obrigatorio or cpf:
        if not cpf_valido(cpf):
            raise ErroNegocio("CPF deve conter exatamente 11 dígitos válidos.")

    return nome, cpf, email


def _cpf_ja_cadastrado(cpf: str, ignorar_id: int = 0) -> bool:
    """
    Verifica se o CPF já existe no banco comparando o hash bcrypt linha a linha.
    Necessário porque o bcrypt possui salt dinâmico e impede busca direta por igualdade.
    """
    registros = query("SELECT id, cpf_hash FROM clientes")
    for r in registros:
        if r["id"] != ignorar_id and conferir(cpf, r["cpf_hash"]):
            return True
    return False


def listar(termo: str = ""):
    """
    Lista todos os clientes ou realiza busca dinâmica.
    Permite busca por nome, email, telefone ou CPF completo digitado no campo de busca.
    """
    termo = (termo or "").strip()
    if not termo:
        return query(f"SELECT {COLUNAS} FROM clientes ORDER BY nome ASC")

    filtro = f"%{termo}%"
    resultados = query(
        f"SELECT {COLUNAS} FROM clientes WHERE nome LIKE %s OR email LIKE %s OR telefone LIKE %s ORDER BY nome ASC",
        (filtro, filtro, filtro)
    )

    # Busca exata por CPF (se o termo tiver 11 dígitos)
    cpf_busca = apenas_digitos(termo)
    if len(cpf_busca) == 11:
        ids_ja_encontrados = {item["id"] for item in resultados}
        todos_clientes = query("SELECT id, cpf_hash FROM clientes")
        for c in todos_clientes:
            if c["id"] not in ids_ja_encontrados and conferir(cpf_busca, c["cpf_hash"]):
                cliente_cpf = query(f"SELECT {COLUNAS} FROM clientes WHERE id = %s", (c["id"],))
                resultados.extend(cliente_cpf)

    return resultados


def obter(id_: int) -> dict:
    """Retorna os dados de um cliente específico ou erro 404."""
    clientes = query(f"SELECT {COLUNAS} FROM clientes WHERE id = %s", (id_,))
    if not clientes:
        raise ErroNegocio("Cliente não encontrado.", 404)
    return clientes[0]


def cadastrar(dados: dict) -> dict:
    """Cadastra um novo cliente com CPF criptografado."""
    nome, cpf, email = _validar_dados(dados, cpf_obrigatorio=True)
    if _cpf_ja_cadastrado(cpf):
        raise ErroNegocio("Já existe cliente cadastrado com este CPF.", 409)

    novo_id = execute(
        "INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES (%s, %s, %s, %s, %s)",
        (nome, gerar_hash(cpf), dados.get("telefone"), email or None, dados.get("endereco"))
    )
    return obter(novo_id)


def editar(id_: int, dados: dict) -> dict:
    """Atualiza dados do cliente existente e, opcionalmente, atualiza o CPF."""
    obter(id_)  # Garante existência
    nome, cpf, email = _validar_dados(dados, cpf_obrigatorio=False)

    if cpf and _cpf_ja_cadastrado(cpf, ignorar_id=id_):
        raise ErroNegocio("Já existe outro cliente com este CPF.", 409)

    execute(
        "UPDATE clientes SET nome = %s, telefone = %s, email = %s, endereco = %s WHERE id = %s",
        (nome, dados.get("telefone"), email or None, dados.get("endereco"), id_)
    )

    if cpf:
        execute("UPDATE clientes SET cpf_hash = %s WHERE id = %s", (gerar_hash(cpf), id_))

    return obter(id_)


def excluir(id_: int):
    """Exclui cliente caso não possua registros vinculados (pets)."""
    obter(id_)
    if query("SELECT id FROM pets WHERE cliente_id = %s LIMIT 1", (id_,)):
        raise ErroNegocio("Cliente possui pets vinculados. Exclua os pets antes.", 409)
    execute("DELETE FROM clientes WHERE id = %s", (id_,))
