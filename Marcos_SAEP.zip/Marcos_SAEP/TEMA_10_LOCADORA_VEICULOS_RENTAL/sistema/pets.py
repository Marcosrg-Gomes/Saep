"""
Regras de Negócio e Operações para Pets (Animais de Estimação)
Todo pet pertence obrigatoriamente a um cliente cadastrado e possui chip único.
"""
from db import ErroNegocio, bloquear_se_existir, buscar_um, execute, query

SELECT = """
    SELECT
        p.id,
        p.cliente_id,
        c.nome AS cliente_nome,
        p.chip,
        p.nome,
        p.especie,
        p.raca,
        p.porte,
        p.observacao
    FROM pets p
    JOIN clientes c ON c.id = p.cliente_id
"""


def _converter_inteiro(valor, mensagem):
    try:
        return int(valor)
    except (TypeError, ValueError):
        raise ErroNegocio(mensagem)


def _validar_dados(dados: dict, id_: int = 0):
    """Valida campos e garante que o tutor exista e o microchip seja único."""
    chip = (dados.get("chip") or "").strip()
    nome = (dados.get("nome") or "").strip()
    especie = (dados.get("especie") or "").strip()
    raca = (dados.get("raca") or "").strip()
    porte = (dados.get("porte") or "").strip()
    observacao = (dados.get("observacao") or "").strip()

    if not chip or len(chip) < 6:
        raise ErroNegocio("Informe o código de identificação ou microchip do pet (mínimo 6 caracteres).")
    if not nome:
        raise ErroNegocio("Informe o nome do pet.")
    if not especie:
        raise ErroNegocio("Informe a espécie do animal (ex.: Canino, Felino).")
    if not raca:
        raise ErroNegocio("Informe a raça.")

    cliente_id = _converter_inteiro(dados.get("cliente_id"), "Selecione o tutor responsável pelo pet.")
    buscar_um("SELECT id FROM clientes WHERE id = %s", (cliente_id,), "O tutor informado não está cadastrado.")

    # Unicidade do Chip
    bloquear_se_existir(
        "SELECT id FROM pets WHERE chip = %s AND id <> %s",
        (chip, id_),
        "Já existe outro animal cadastrado com este microchip."
    )

    return cliente_id, chip, nome, especie, raca, porte, observacao


def listar():
    """Lista todos os pets com o nome do respectivo tutor."""
    return query(SELECT + " ORDER BY c.nome ASC, p.nome ASC")


def obter(id_: int):
    """Busca pet por ID."""
    return buscar_um(SELECT + " WHERE p.id = %s", (id_,), "Pet não encontrado.")


def cadastrar(dados: dict):
    """Cadastra pet associado a um tutor."""
    params = _validar_dados(dados)
    novo_id = execute(
        "INSERT INTO pets (cliente_id, chip, nome, especie, raca, porte, observacao) VALUES (%s, %s, %s, %s, %s, %s, %s)",
        params
    )
    return obter(novo_id)


def editar(id_: int, dados: dict):
    """Atualiza dados do pet."""
    obter(id_)
    params = _validar_dados(dados, id_)
    execute(
        "UPDATE pets SET cliente_id=%s, chip=%s, nome=%s, especie=%s, raca=%s, porte=%s, observacao=%s WHERE id=%s",
        (*params, id_)
    )
    return obter(id_)


def excluir(id_: int):
    """Exclui pet se não tiver consultas/agendamentos pendentes."""
    obter(id_)
    bloquear_se_existir(
        "SELECT id FROM agendamentos WHERE pet_id = %s",
        (id_,),
        "O animal possui atendimentos agendados. Exclua os agendamentos antes de remover o pet."
    )
    execute("DELETE FROM pets WHERE id = %s", (id_,))
