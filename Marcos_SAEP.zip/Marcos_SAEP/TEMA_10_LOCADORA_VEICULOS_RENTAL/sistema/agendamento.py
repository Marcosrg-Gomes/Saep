"""
Regras de Negócio e Operações para Agendamentos de Consultas e Serviços
Exibe dados ordenados por data e permite reagendamento de consultas.
"""
from datetime import datetime
from db import ErroNegocio, execute, query

STATUS_PERMITIDOS = ("AGENDADO", "EM_ANDAMENTO", "CONCLUIDO", "CANCELADO")

SELECT = """
SELECT a.id, a.data_agendamento, a.status, a.observacao,
       s.id AS servico_id, s.descricao AS servico, s.valor,
       p.id AS pet_id, p.chip, p.nome AS pet_nome, p.especie, p.raca,
       c.id AS cliente_id, c.nome AS cliente_nome, c.telefone, c.email
FROM agendamentos a
JOIN pets p ON p.id = a.pet_id
JOIN clientes c ON c.id = p.cliente_id
JOIN servicos s ON s.id = a.servico_id
"""


def _converter_data(valor: str) -> datetime:
    """Converte texto de data ISO ou HTML datetime-local para objeto datetime."""
    try:
        return datetime.fromisoformat((valor or "").replace("Z", ""))
    except ValueError:
        raise ErroNegocio("Formato de data e hora inválido.")


def listar():
    """
    Lista agendamentos obrigatoriamente ordenados de forma crescente por data.
    Regra primordial do SAEP.
    """
    return query(SELECT + " ORDER BY a.data_agendamento ASC, a.id ASC")


def listar_servicos():
    """Lista catálogo de serviços disponíveis."""
    return query("SELECT id, descricao, valor FROM servicos ORDER BY descricao ASC")


def obter(id_: int) -> dict:
    """Busca agendamento por ID com todos os relacionamentos."""
    registros = query(SELECT + " WHERE a.id = %s", (id_,))
    if not registros:
        raise ErroNegocio("Agendamento não encontrado.", 404)
    return registros[0]


def cadastrar(dados: dict) -> dict:
    """Cria novo agendamento validando pet e serviço."""
    data = _converter_data(dados.get("data_agendamento"))
    pet_id = dados.get("pet_id")
    servico_id = dados.get("servico_id")

    if not query("SELECT id FROM pets WHERE id = %s", (pet_id,)):
        raise ErroNegocio("Pet informado não foi encontrado.", 404)

    if not query("SELECT id FROM servicos WHERE id = %s", (servico_id,)):
        raise ErroNegocio("Serviço informado não foi encontrado.", 404)

    novo_id = execute(
        "INSERT INTO agendamentos (pet_id, servico_id, data_agendamento, observacao) VALUES (%s, %s, %s, %s)",
        (pet_id, servico_id, data, dados.get("observacao"))
    )
    return obter(novo_id)


def editar(id_: int, dados: dict) -> dict:
    """
    Reagendamento: atualiza a data_agendamento (obrigatória), status e observações.
    """
    atual = obter(id_)
    data = _converter_data(dados.get("data_agendamento"))
    status = dados.get("status", atual["status"])

    if status not in STATUS_PERMITIDOS:
        raise ErroNegocio(f"Status inválido. Escolha entre: {', '.join(STATUS_PERMITIDOS)}")

    execute(
        "UPDATE agendamentos SET data_agendamento = %s, status = %s, observacao = %s WHERE id = %s",
        (data, status, dados.get("observacao", atual["observacao"]), id_)
    )
    return obter(id_)


def excluir(id_: int):
    """Exclui agendamento."""
    obter(id_)
    execute("DELETE FROM agendamentos WHERE id = %s", (id_,))
