"""
Módulo de Autenticação, Criptografia (Bcrypt) e Gestão de Sessões
Atende aos requisitos de expiração temporal e LGPD para senhas e CPF.
"""
import time
import bcrypt
from flask import session
from db import ErroNegocio, query

# Tempo limite de expiração da sessão em segundos (30 minutos)
EXPIRACAO_SEGUNDOS = 30 * 60


def gerar_hash(texto: str) -> str:
    """Gera hash seguro bcrypt com salt para senhas e CPF."""
    return bcrypt.hashpw(texto.encode("utf-8"), bcrypt.gensalt(rounds=10)).decode("utf-8")


def conferir(texto: str, hash_salvo: str) -> bool:
    """Verifica se o texto em claro corresponde ao hash bcrypt salvo."""
    try:
        return bcrypt.checkpw(texto.encode("utf-8"), hash_salvo.encode("utf-8"))
    except Exception:
        return False


def autenticar(login: str, senha: str) -> dict:
    """
    Valida credenciais do usuário.
    Gera erro genérico em caso de falha para segurança contra enumeração.
    """
    login = (login or "").strip()
    senha = senha or ""

    if not login or not senha:
        raise ErroNegocio("Informe o usuário e a senha.")

    usuarios = query("SELECT id, nome, login, senha_hash FROM usuarios WHERE login = %s", (login,))
    if not usuarios or not conferir(senha, usuarios[0]["senha_hash"]):
        raise ErroNegocio("Usuário ou senha inválidos.", 401)

    return usuarios[0]


def iniciar_sessao(usuario: dict):
    """Inicializa os dados de sessão do Flask com carimbo de tempo."""
    session.clear()
    session.permanent = True
    session["usuario_id"] = usuario["id"]
    session["nome"] = usuario["nome"]
    session["login_em"] = time.time()


def logado() -> bool:
    """
    Confere se há usuário logado e se o tempo limite de sessão não expirou.
    Caso tenha expirado, limpa a sessão e retorna False.
    """
    if "usuario_id" in session:
        tempo_decorrido = time.time() - session.get("login_em", 0)
        if tempo_decorrido <= EXPIRACAO_SEGUNDOS:
            return True
    session.clear()
    return False
