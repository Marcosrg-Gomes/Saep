"""
Mapeamento de Rotas HTTP, Páginas Web e Endpoints de API REST
Proteção global com middleware @before_request para validação de sessão.
"""
import mysql.connector
from flask import Blueprint, abort, jsonify, redirect, request, send_from_directory, session
import agendamento, autenticacao as auth, clientes, pets
from db import ErroNegocio, testar_conexao

bp = Blueprint("rotas", __name__)

ROTAS_LIVRES = ("/", "/login", "/api/login", "/api/logout", "/api/teste-conexao")
PAGINAS = ("login", "principal", "clientes", "pets", "agendamentos")
MODULOS = {
    "clientes": clientes,
    "pets": pets,
    "agendamentos": agendamento
}


@bp.before_request
def verificar_autenticacao():
    """
    Middleware de Segurança:
    Garante que rotas protegidas exijam usuário autenticado dentro do tempo de expiração.
    """
    if request.path in ROTAS_LIVRES or auth.logado():
        return None

    if request.path.startswith("/api/"):
        return jsonify(erro="Sessão expirada ou não autenticada. Faça login novamente."), 401

    return redirect("/login?expirou=1")


@bp.app_errorhandler(ErroNegocio)
def tratar_erro_negocio(erro):
    """Trata erros de validação devolvendo status e mensagem formatada."""
    return jsonify(erro=erro.mensagem), erro.status


@bp.app_errorhandler(mysql.connector.Error)
def tratar_erro_banco(erro):
    """Trata falhas de SQL sem vazar credenciais ou detalhes de infraestrutura."""
    return jsonify(erro="Erro interno ao acessar o banco de dados."), 500


def corpo_json():
    """Helper para obter o JSON enviado na requisição."""
    return request.get_json(silent=True) or {}


# ====================================================================
# PÁGINAS HTML (INTERFACE COM O USUÁRIO)
# ====================================================================

@bp.route("/")
def raiz():
    return redirect("/principal" if auth.logado() else "/login")


@bp.route("/<pagina>")
def renderizar_pagina(pagina):
    if pagina not in PAGINAS:
        abort(404)
    return send_from_directory("templates", f"{pagina}.html")


# ====================================================================
# ENDPOINTS DE AUTENTICAÇÃO E SUPORTE
# ====================================================================

@bp.post("/api/login")
def login():
    dados = corpo_json()
    usuario = auth.autenticar(dados.get("login"), dados.get("senha"))
    auth.iniciar_sessao(usuario)
    return jsonify(ok=True, nome=session["nome"])


@bp.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@bp.get("/api/me")
def me():
    """Retorna dados do usuário atualmente logado para exibição na tela principal."""
    return jsonify(nome=session["nome"])


@bp.get("/api/teste-conexao")
def teste():
    return jsonify(testar_conexao())


@bp.get("/api/servicos")
def servicos():
    return jsonify(agendamento.listar_servicos())


# ====================================================================
# CRUD DINÂMICO PARA /api/clientes, /api/pets E /api/agendamentos
# ====================================================================

def obter_modulo(recurso: str):
    modulo = MODULOS.get(recurso)
    if not modulo:
        raise ErroNegocio("Recurso não encontrado.", 404)
    return modulo


@bp.route("/api/<recurso>", methods=["GET", "POST"])
def colecao(recurso):
    mod = obter_modulo(recurso)
    if request.method == "POST":
        return jsonify(mod.cadastrar(corpo_json())), 201

    # Clientes permite busca via query param ?q=
    if "q" in request.args and hasattr(mod, "listar"):
        return jsonify(mod.listar(request.args.get("q")))

    return jsonify(mod.listar())


@bp.route("/api/<recurso>/<int:id_>", methods=["GET", "PUT", "DELETE"])
def elemento(recurso, id_):
    mod = obter_modulo(recurso)
    if request.method == "GET":
        return jsonify(mod.obter(id_))
    elif request.method == "PUT":
        return jsonify(mod.editar(id_, corpo_json()))
    elif request.method == "DELETE":
        mod.excluir(id_)
        return jsonify(ok=True)
