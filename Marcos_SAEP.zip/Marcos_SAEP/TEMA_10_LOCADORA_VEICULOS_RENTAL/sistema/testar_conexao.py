import os
import sys

# Se estiver na raiz do tema, adiciona a subpasta 'sistema' ao sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SISTEMA_DIR = os.path.join(BASE_DIR, "sistema") if os.path.isdir(os.path.join(BASE_DIR, "sistema")) else BASE_DIR

if SISTEMA_DIR not in sys.path:
    sys.path.insert(0, SISTEMA_DIR)

from db import testar_conexao

try:
    info = testar_conexao()
    print("==================================================")
    print("  SUCESSO: Conexão OK com MySQL!")
    print(f"  Banco ativo:  {info.get('banco')}")
    print(f"  Versão MySQL: {info.get('versao')}")
    print("==================================================")
except Exception as e:
    print("==================================================")
    print("  ERRO AO CONECTAR NO MYSQL:")
    print("  ", e)
    print("==================================================")
