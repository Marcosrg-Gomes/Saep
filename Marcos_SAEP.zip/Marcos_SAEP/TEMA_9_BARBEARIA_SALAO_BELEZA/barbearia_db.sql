-- ====================================================================
-- Script: barbearia_db.sql | MySQL 8+
-- Tema: Barbearia & Salão de Beleza / Estética
-- Padrão Oficial SAEP SENAI (mínimo de 3 registros por tabela)
-- ====================================================================

DROP DATABASE IF EXISTS barbearia_db;
CREATE DATABASE barbearia_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE barbearia_db;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha_hash CHAR(60) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  cpf_hash CHAR(60) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(120),
  endereco VARCHAR(200),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recurso Secundário: Cartão Fidelidade / Perfil de Estilo do Cliente
CREATE TABLE IF NOT EXISTS perfis_fidelidade (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  codigo_fidelidade VARCHAR(30) NOT NULL UNIQUE,
  estilo_corte VARCHAR(60) NOT NULL,           -- Fade Degradê, Social Clássico, Barba Lenhador
  preferencia_produto VARCHAR(100),            -- Pomada fosca, óleo hidratante
  pontos_acumulados INT DEFAULT 0,
  CONSTRAINT fk_fidelidade_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descricao VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  perfil_id INT NOT NULL,
  servico_id INT NOT NULL,
  data_agendamento DATETIME NOT NULL,
  status ENUM('AGENDADO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'AGENDADO',
  observacao VARCHAR(255),
  CONSTRAINT fk_ag_fidelidade FOREIGN KEY (perfil_id) REFERENCES perfis_fidelidade(id),
  CONSTRAINT fk_ag_barb_serv FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

INSERT INTO usuarios (nome, login, senha_hash) VALUES
('Mestre Barbeiro', 'admin', '$2b$10$qizaoAEHzt5Hz/vRqXSL.uYENkSH9GpokflvL.8V1mn3QEBTyXZiO'),
('Diego Hair Stylist', 'diego', '$2b$10$r32LnLIp2cB54XivPH1Nau70ftffbmF3BPyPm8.VZIBkgD4MR.KTK'),
('Juliana Recepção', 'juliana', '$2b$10$UWZ0bg.GPd50uIKOhkyUqu3.n4ceo3X8ZX.P1S.wQlNfqh88D6mTO');

INSERT INTO clientes (nome, cpf_hash, telefone, email, endereco) VALUES
('Thiago Silva', '$2b$10$KhQB9kIqUe31KTL6YcE3ouJPBhHvYgzEdile2lXILS36A55FGFk7W', '(11) 98888-0101', 'thiago@email.com', 'Rua Augusta, 1200'),
('Rodrigo Maia', '$2b$10$bsggD78dGRaHNDAG42jEwu7aPq/utYq/OIk1bqaDFPECHp2yoTthG', '(11) 97777-0202', 'rodrigo@email.com', 'Av. Faria Lima, 3500'),
('Felipe Neves', '$2b$10$hceDyXaqS2nBr69H/FWUZuwqw3sBhxfin.Zzi4tVisZ4NWCNZVC3K', '(11) 96666-0303', 'felipe@email.com', 'Rua Oscar Freire, 88');

INSERT INTO perfis_fidelidade (cliente_id, codigo_fidelidade, estilo_corte, preferencia_produto, pontos_acumulados) VALUES
(1, 'FID-BARB-001', 'Fade Degradê Navalhado', 'Pomada Matte Sem Brilho', 150),
(2, 'FID-BARB-002', 'Barba Terapia com Toalha Quente', 'Óleo de Barba Alecrim', 80),
(3, 'FID-BARB-003', 'Corte Social na Tesoura', 'Gel Fixador Forte', 40);

INSERT INTO servicos (descricao, valor) VALUES
('Corte Masculino Degradê', 60.00),
('Barba Completa e Alinhamento', 45.00),
('Combo Corte + Barba + Sobrancelha', 95.00);

INSERT INTO agendamentos (perfil_id, servico_id, data_agendamento, status, observacao) VALUES
(1, 1, '2026-11-06 16:00:00', 'AGENDADO', 'Cliente prefere atendimento com Diego'),
(2, 2, '2026-11-07 10:30:00', 'AGENDADO', 'Aplicar toalha aromática'),
(3, 3, '2026-11-08 14:00:00', 'AGENDADO', 'Prepara café expresso na chegada');
